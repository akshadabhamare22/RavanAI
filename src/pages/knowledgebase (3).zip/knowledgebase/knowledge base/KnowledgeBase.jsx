// import React, { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import { HelpCircle, Plus, Database, Folder, Clock, X } from "lucide-react";

// export default function KnowledgeBase() {
//   const navigate = useNavigate();
//   const [bases, setBases] = useState([]);
//   const [showCreate, setShowCreate] = useState(false);
//   const [toast, setToast] = useState(null);

//   // Load existing bases
//   useEffect(() => {
//     try {
//       const raw = localStorage.getItem("ravanai_knowledge_bases");
//       const parsed = raw ? JSON.parse(raw) : [];
//       setBases(Array.isArray(parsed) ? parsed : []);
//     } catch {
//       setBases([]);
//     }
//   }, []);

//   // ============================================================
//   // CREATE HANDLER — save + navigate + auto-open Add Source
//   // ============================================================
//   const handleCreate = (payload) => {
//     const newBase = {
//       id:
//         payload.name.toLowerCase().replace(/\s+/g, "-") +
//         "-" +
//         Date.now().toString().slice(-6),
//       name: payload.name,
//       uuid: generateUUID(),
//       status: "READY",
//       sourcesCount: 0,
//       updatedAt: "Just now",
//     };

//     // Save to localStorage
//     let existing = [];
//     try {
//       const raw = localStorage.getItem("ravanai_knowledge_bases");
//       existing = raw ? JSON.parse(raw) : [];
//       if (!Array.isArray(existing)) existing = [];
//     } catch {
//       existing = [];
//     }

//     const updated = [newBase, ...existing];
//     try {
//       localStorage.setItem(
//         "ravanai_knowledge_bases",
//         JSON.stringify(updated)
//       );
//     } catch (e) {
//       console.error("localStorage error:", e);
//     }

//     setBases(updated);
//     setShowCreate(false);

//     setToast("Knowledge base created");
//     setTimeout(() => setToast(null), 3000);

//     // ✅ Navigate with flag to auto-open Add Source modal
//     setTimeout(() => {
//       navigate(`/knowledge-base/${newBase.id}?addSource=true`);
//     }, 400);
//   };

//   return (
//     <div className="min-h-screen bg-zinc-100 text-zinc-900 transition-colors duration-300 dark:bg-[#09090B] dark:text-zinc-100">
//       {/* Toast */}
//       {toast && (
//         <div className="fixed right-6 top-6 z-[100] flex min-w-[280px] items-center gap-3 overflow-hidden rounded-xl border border-emerald-500/30 bg-white shadow-xl dark:bg-[#101012]">
//           <div className="flex flex-1 items-center gap-3 px-4 py-3">
//             <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-500">
//               <svg
//                 width="14"
//                 height="14"
//                 viewBox="0 0 24 24"
//                 fill="none"
//                 stroke="currentColor"
//                 strokeWidth="3"
//                 strokeLinecap="round"
//                 strokeLinejoin="round"
//               >
//                 <polyline points="20 6 9 17 4 12" />
//               </svg>
//             </div>
//             <span className="text-sm font-medium text-zinc-800 dark:text-zinc-200">
//               {toast}
//             </span>
//           </div>
//         </div>
//       )}

//       <main className="mx-auto max-w-[1600px] space-y-5 p-4 sm:p-6 lg:p-7">
//         {/* ============ HEADER ============ */}
//         <section>
//           <div className="flex flex-wrap items-center gap-2">
//             <h1 className="text-[22px] font-semibold tracking-tight text-zinc-900 dark:text-zinc-100 sm:text-2xl">
//               Knowledge Base
//             </h1>
//             <HelpCircle size={15} className="text-zinc-400" />
//           </div>

//           <div className="mt-1.5 flex items-center gap-2 text-sm text-zinc-600 dark:text-zinc-500">
//             <span>
//               <span className="font-semibold text-zinc-900 dark:text-zinc-200">
//                 {bases.length}
//               </span>{" "}
//               knowledge base{bases.length !== 1 ? "s" : ""}
//             </span>
//             <span>•</span>
//             <span className="font-mono text-xs"># 012854ee...681e</span>
//           </div>
//         </section>

//         {/* ============ GRID ============ */}
//         <section className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
//           {/* Create Card */}
//           <button
//             type="button"
//             onClick={() => setShowCreate(true)}
//             className="group flex min-h-[280px] flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-black/[0.15] bg-zinc-50 p-5 transition hover:border-cyan-500/40 hover:bg-cyan-50 dark:border-white/[0.10] dark:bg-white/[0.02] dark:hover:border-cyan-400/40 dark:hover:bg-cyan-500/[0.03]"
//           >
//             <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-white text-zinc-500 transition group-hover:bg-cyan-500/10 group-hover:text-cyan-600 dark:bg-white/[0.05] dark:group-hover:text-cyan-400">
//               <Plus size={20} />
//             </div>
//             <div className="text-center">
//               <p className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">
//                 Create Knowledge Base
//               </p>
//               <p className="mt-0.5 text-xs text-zinc-500">
//                 Add sources for agents
//               </p>
//             </div>
//           </button>

//           {/* KB Cards */}
//           {bases.map((base) => (
//             <div
//               key={base.id}
//               onClick={() => navigate(`/knowledge-base/${base.id}`)}
//               className="group flex min-h-[280px] cursor-pointer flex-col rounded-2xl border border-black/[0.06] bg-white p-5 transition hover:border-cyan-500/30 hover:shadow-md dark:border-white/[0.08] dark:bg-[#101012] dark:hover:border-cyan-400/30"
//             >
//               <div className="flex items-start justify-between">
//                 <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-cyan-500/25 bg-cyan-500/[0.06]">
//                   <Database
//                     size={16}
//                     className="text-cyan-600 dark:text-cyan-400"
//                   />
//                 </div>

//                 {base.status === "READY" && (
//                   <span className="flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/[0.08] px-2 py-0.5 text-[10px] font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
//                     <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
//                     READY
//                   </span>
//                 )}
//               </div>

//               <h3 className="mt-4 truncate text-[15px] font-semibold text-zinc-900 dark:text-zinc-100">
//                 {base.name}
//               </h3>

//               <p className="mt-1 truncate font-mono text-[11px] text-zinc-400 dark:text-zinc-500">
//                 {base.uuid}
//               </p>

//               <div className="mt-4 border-t border-black/[0.06] dark:border-white/[0.06]" />

//               <div className="mt-auto flex items-center justify-between pt-4">
//                 <div className="flex items-center gap-1.5 text-[11px] text-zinc-500">
//                   <Folder size={12} />
//                   <span>
//                     {base.sourcesCount || 0} source
//                     {base.sourcesCount !== 1 ? "s" : ""}
//                   </span>
//                 </div>

//                 <div className="flex items-center gap-1.5 text-[11px] text-zinc-400 dark:text-zinc-500">
//                   <Clock size={11} />
//                   <span>{base.updatedAt}</span>
//                 </div>
//               </div>
//             </div>
//           ))}
//         </section>
//       </main>

//       {/* Create Modal */}
//       {showCreate && (
//         <CreateKnowledgeBaseModal
//           onClose={() => setShowCreate(false)}
//           onCreate={handleCreate}
//         />
//       )}
//     </div>
//   );
// }

// // ============================================================
// // CREATE MODAL
// // ============================================================

// function CreateKnowledgeBaseModal({ onClose, onCreate }) {
//   const [name, setName] = useState("");

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (!name.trim()) return;
//     onCreate({ name: name.trim() });
//   };

//   return (
//     <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
//       <div
//         className="absolute inset-0 bg-black/50 backdrop-blur-sm"
//         onClick={onClose}
//       />

//       <div className="relative w-full max-w-[560px] overflow-hidden rounded-2xl border border-black/[0.08] bg-white shadow-2xl dark:border-white/[0.08] dark:bg-[#101012]">
//         <div className="flex items-start justify-between gap-4 px-6 pt-6">
//           <h3 className="text-lg font-bold tracking-tight text-zinc-900 dark:text-zinc-100">
//             Create Knowledge Base
//           </h3>
//           <button
//             type="button"
//             onClick={onClose}
//             className="mt-0.5 rounded-md p-1 text-zinc-500 transition hover:bg-black/[0.05] hover:text-zinc-800 dark:hover:bg-white/[0.06]"
//           >
//             <X size={16} />
//           </button>
//         </div>

//         <p className="mt-2 px-6 text-[13px] leading-relaxed text-zinc-600 dark:text-zinc-400">
//           A knowledge base stores information your AI agents can reference
//           during calls.
//         </p>

//         <form onSubmit={handleSubmit} className="px-6 pb-6 pt-5">
//           <label
//             htmlFor="kb-name"
//             className="mb-1.5 block text-[12px] font-medium text-zinc-700 dark:text-zinc-300"
//           >
//             Name
//           </label>
//           <input
//             id="kb-name"
//             autoFocus
//             type="text"
//             value={name}
//             onChange={(e) => setName(e.target.value)}
//             placeholder="e.g. Product Support KB"
//             required
//             className="h-10 w-full rounded-lg border border-black/[0.08] bg-white px-3 text-sm text-zinc-900 outline-none transition placeholder:text-zinc-400 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 dark:border-white/[0.08] dark:bg-[#0e0f12] dark:text-zinc-100 dark:placeholder:text-zinc-500 dark:focus:border-cyan-400"
//           />

//           <div className="mt-6 flex items-center justify-end gap-3">
//             <button
//               type="button"
//               onClick={onClose}
//               className="rounded-lg px-4 py-2 text-sm font-medium text-zinc-700 transition hover:bg-black/[0.04] dark:text-zinc-300 dark:hover:bg-white/[0.05]"
//             >
//               Cancel
//             </button>
//             <button
//               type="submit"
//               className="rounded-lg bg-cyan-500 px-5 py-2 text-sm font-semibold text-white transition hover:bg-cyan-400 active:scale-[0.98] dark:bg-cyan-400 dark:text-slate-950"
//             >
//               Create
//             </button>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// }

// // ============================================================
// // HELPER
// // ============================================================

// function generateUUID() {
//   return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
//     const r = (Math.random() * 16) | 0;
//     const v = c === "x" ? r : (r & 0x3) | 0x8;
//     return v.toString(16);
//   });
// }


// import React, {
//   useCallback,
//   useEffect,
//   useState,
// } from "react";
// import config from "../../../config/Config";
// import { useNavigate } from "react-router-dom";

// import {
//   HelpCircle,
//   Plus,
//   Database,
//   Folder,
//   Clock,
//   RefreshCw,
//   Eye,
//   Pencil,
//   Trash2,
// } from "lucide-react";

// import axios from "axios";

// // ============================================================
// // KNOWLEDGE BASE COMPONENTS
// // ============================================================

// import CreateKnowledgeBase from "./CreateKnowledgeBase";
// import CreateSource from "../source/CreateSource";
// import DeleteKnowledgeBase from "./DeleteKnowledgeBase";
// import EditKnowledgeBase from "./EditKnowledgeBase";
// import ViewKnowledgeBase from "./ViewKnowledgeBase";

// export default function KnowledgeBase() {
//   const navigate = useNavigate();

//   // ============================================================
//   // STATES
//   // ============================================================

//   const [bases, setBases] = useState([]);
//   const [total, setTotal] = useState(0);

//   const [loading, setLoading] = useState(true);
//   const [refreshing, setRefreshing] = useState(false);

//   const [toast, setToast] = useState(null);
//   const [error, setError] = useState("");

//   const [showCreateSource, setShowCreateSource] = useState(false);
// const [createdKnowledgeBaseId, setCreatedKnowledgeBaseId] = useState(null);

//   // ============================================================
//   // MODAL STATES
//   // ============================================================

//   const [showCreate, setShowCreate] = useState(false);
//   const [showView, setShowView] = useState(false);
//   const [showEdit, setShowEdit] = useState(false);
//   const [showDelete, setShowDelete] = useState(false);

//   // Selected Knowledge Base
//   const [selectedKnowledgeBase, setSelectedKnowledgeBase] =
//     useState(null);

//   // ============================================================
//   // GET KNOWLEDGE BASES
//   // GET /api/v1/knowledge-bases
//   // ============================================================

//   const fetchKnowledgeBases = useCallback(
//     async (showLoader = true) => {
//       try {
//         if (showLoader) {
//           setLoading(true);
//         } else {
//           setRefreshing(true);
//         }

//         setError("");

//         const response = await axios.get(
//   `${config.BASE_URL}/knowledge-bases`,
//   {
//     headers: {
//       Accept: "*/*",
//     },
//   }
// );

//         console.log(
//           "Knowledge Bases API Response:",
//           response.data
//         );

//         const items = Array.isArray(response.data?.items)
//           ? response.data.items
//           : [];

//         const formattedBases = items.map((base) => ({
//           id: base.id,
//           name: base.name || "Untitled",
//           description: base.description || "",
//           status: base.status || "active",
//           created_at: base.created_at,
//           updated_at: base.updated_at,

//           // Backend ID
//           uuid: base.id,

//           // Source API will be integrated later
//           sourcesCount: 0,
//         }));

//         setBases(formattedBases);

//         setTotal(
//           typeof response.data?.total === "number"
//             ? response.data.total
//             : formattedBases.length
//         );
//       } catch (err) {
//         console.error(
//           "Get Knowledge Bases Error:",
//           err
//         );

//         const message =
//           err?.response?.data?.detail ||
//           err?.response?.data?.message ||
//           "Failed to load knowledge bases.";

//         setError(message);
//         setBases([]);
//         setTotal(0);
//       } finally {
//         setLoading(false);
//         setRefreshing(false);
//       }
//     },
//     []
//   );

//   // ============================================================
//   // INITIAL LOAD
//   // ============================================================

//   useEffect(() => {
//     fetchKnowledgeBases();
//   }, [fetchKnowledgeBases]);

//   // ============================================================
//   // DATE FORMAT
//   // ============================================================

//   const formatDate = (dateString) => {
//     if (!dateString) {
//       return "-";
//     }

//     try {
//       return new Date(dateString).toLocaleString(
//         "en-IN",
//         {
//           day: "2-digit",
//           month: "short",
//           year: "numeric",
//           hour: "2-digit",
//           minute: "2-digit",
//         }
//       );
//     } catch {
//       return dateString;
//     }
//   };

//   // ============================================================
//   // TOAST
//   // ============================================================

//   const showToast = (message) => {
//     setToast(message);

//     setTimeout(() => {
//       setToast(null);
//     }, 3000);
//   };

//   // ============================================================
//   // CREATE
//   // ============================================================

// const handleCreate = async (createdKnowledgeBase) => {
//   console.log(
//     "Created Knowledge Base:",
//     createdKnowledgeBase
//   );

//   setShowCreate(false);

//   if (!createdKnowledgeBase?.id) {
//     showToast("Knowledge base created, but ID was not returned.");
//     return;
//   }

//   // Store newly created knowledge base ID
//   setCreatedKnowledgeBaseId(createdKnowledgeBase.id);

//   // Refresh knowledge base list
//   await fetchKnowledgeBases(false);

//   showToast("Knowledge base created successfully");

//   // Open Create Source automatically
//   setTimeout(() => {
//     setShowCreateSource(true);
//   }, 300);
// };

//   // ============================================================
//   // VIEW
//   // ============================================================

//   const handleView = (base) => {
//     setSelectedKnowledgeBase(base);
//     setShowView(true);
//   };

//   // ============================================================
//   // EDIT
//   // ============================================================

//   const handleEdit = (base) => {
//     setSelectedKnowledgeBase(base);
//     setShowEdit(true);
//   };

//   // ============================================================
//   // DELETE
//   // ============================================================

//   const handleDelete = (base) => {
//     setSelectedKnowledgeBase(base);
//     setShowDelete(true);
//   };

//   // ============================================================
//   // EDIT SUCCESS
//   // ============================================================

//   const handleUpdated = async (updatedKnowledgeBase) => {
//     console.log(
//       "Updated Knowledge Base:",
//       updatedKnowledgeBase
//     );

//     setShowEdit(false);
//     setSelectedKnowledgeBase(null);

//     await fetchKnowledgeBases(false);

//     showToast("Knowledge base updated successfully");
//   };

//   // ============================================================
//   // DELETE SUCCESS
//   // ============================================================

//   const handleDeleted = async () => {
//     setShowDelete(false);
//     setSelectedKnowledgeBase(null);

//     await fetchKnowledgeBases(false);

//     showToast("Knowledge base deleted successfully");
//   };

//   // ============================================================
//   // REFRESH
//   // ============================================================

//   const handleRefresh = async () => {
//     await fetchKnowledgeBases(false);

//     showToast("Knowledge bases refreshed");
//   };

//   // ============================================================
//   // OPEN DETAILS PAGE
//   // ============================================================

// const handleOpenKnowledgeBase = (base) => {
//   if (!base?.id) {
//     return;
//   }

//   navigate(`/knowledge-base/${base.id}`);
// };

//   // ============================================================
//   // CLOSE ALL MODALS
//   // ============================================================

// const closeAllModals = () => {
//   setShowCreate(false);
//   setShowCreateSource(false);
//   setShowView(false);
//   setShowEdit(false);
//   setShowDelete(false);
//   setSelectedKnowledgeBase(null);
//   setCreatedKnowledgeBaseId(null);
// };

//   // ============================================================
//   // UI
//   // ============================================================

//   return (
//     <div className="min-h-screen bg-zinc-100 text-zinc-900 transition-colors duration-300 dark:bg-[#09090B] dark:text-zinc-100">
//       {/* ========================================================
//           TOAST
//       ========================================================= */}

//       {toast && (
//         <div className="fixed right-6 top-6 z-[100] flex min-w-[280px] items-center gap-3 overflow-hidden rounded-xl border border-emerald-500/30 bg-white shadow-xl dark:bg-[#101012]">
//           <div className="flex flex-1 items-center gap-3 px-4 py-3">
//             <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-500">
//               <svg
//                 width="14"
//                 height="14"
//                 viewBox="0 0 24 24"
//                 fill="none"
//                 stroke="currentColor"
//                 strokeWidth="3"
//                 strokeLinecap="round"
//                 strokeLinejoin="round"
//               >
//                 <polyline points="20 6 9 17 4 12" />
//               </svg>
//             </div>

//             <span className="text-sm font-medium text-zinc-800 dark:text-zinc-200">
//               {toast}
//             </span>
//           </div>
//         </div>
//       )}

//       {/* ========================================================
//           MAIN
//       ========================================================= */}

//       <main className="mx-auto max-w-[1600px] space-y-5 p-4 sm:p-6 lg:p-7">
//         {/* ======================================================
//             HEADER
//         ======================================================= */}

//         <section>
//           <div className="flex flex-wrap items-center justify-between gap-3">
//             <div>
//               <div className="flex flex-wrap items-center gap-2">
//                 <h1 className="text-[22px] font-semibold tracking-tight text-zinc-900 dark:text-zinc-100 sm:text-2xl">
//                   Knowledge Base
//                 </h1>

//                 <HelpCircle
//                   size={15}
//                   className="text-zinc-400"
//                 />
//               </div>

//               <div className="mt-1.5 flex items-center gap-2 text-sm text-zinc-600 dark:text-zinc-500">
//                 <span>
//                   <span className="font-semibold text-zinc-900 dark:text-zinc-200">
//                     {total}
//                   </span>{" "}
//                   knowledge base
//                   {total !== 1 ? "s" : ""}
//                 </span>

//                 <span>•</span>

//                 <span className="font-mono text-xs">
//                   Knowledge Base Management
//                 </span>
//               </div>
//             </div>

//             {/* Refresh */}
//             <button
//               type="button"
//               onClick={handleRefresh}
//               disabled={refreshing}
//               className="flex items-center gap-2 rounded-lg border border-black/[0.08] bg-white px-3 py-2 text-xs font-medium text-zinc-600 transition hover:bg-black/[0.03] disabled:cursor-not-allowed disabled:opacity-60 dark:border-white/[0.08] dark:bg-[#101012] dark:text-zinc-400 dark:hover:bg-white/[0.04]"
//             >
//               <RefreshCw
//                 size={13}
//                 className={
//                   refreshing
//                     ? "animate-spin"
//                     : ""
//                 }
//               />

//               Refresh
//             </button>
//           </div>
//         </section>

//         {/* ======================================================
//             ERROR
//         ======================================================= */}

//         {error && (
//           <div className="flex items-center justify-between gap-4 rounded-xl border border-red-500/20 bg-red-500/[0.06] px-4 py-3">
//             <div>
//               <p className="text-sm font-medium text-red-600 dark:text-red-400">
//                 {error}
//               </p>

//               <p className="mt-0.5 text-xs text-red-500/80">
//                 Please check your backend connection.
//               </p>
//             </div>

//             <button
//               type="button"
//               onClick={() => fetchKnowledgeBases()}
//               className="rounded-lg bg-red-500 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-red-600"
//             >
//               Retry
//             </button>
//           </div>
//         )}

//         {/* ======================================================
//             GRID
//         ======================================================= */}

//         <section className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
//           {/* ====================================================
//               CREATE CARD
//           ===================================================== */}

//           <button
//             type="button"
//             onClick={() => setShowCreate(true)}
//             className="group flex min-h-[280px] flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-black/[0.15] bg-zinc-50 p-5 transition hover:border-cyan-500/40 hover:bg-cyan-50 dark:border-white/[0.10] dark:bg-white/[0.02] dark:hover:border-cyan-400/40 dark:hover:bg-cyan-500/[0.03]"
//           >
//             <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-white text-zinc-500 transition group-hover:bg-cyan-500/10 group-hover:text-cyan-600 dark:bg-white/[0.05] dark:group-hover:text-cyan-400">
//               <Plus size={20} />
//             </div>

//             <div className="text-center">
//               <p className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">
//                 Create Knowledge Base
//               </p>

//               <p className="mt-0.5 text-xs text-zinc-500">
//                 Add sources for agents
//               </p>
//             </div>
//           </button>

//           {/* ====================================================
//               LOADING
//           ===================================================== */}

//           {loading &&
//             Array.from({ length: 5 }).map(
//               (_, index) => (
//                 <div
//                   key={`skeleton-${index}`}
//                   className="min-h-[280px] animate-pulse rounded-2xl border border-black/[0.06] bg-white p-5 dark:border-white/[0.08] dark:bg-[#101012]"
//                 >
//                   <div className="h-10 w-10 rounded-lg bg-zinc-200 dark:bg-white/[0.08]" />

//                   <div className="mt-5 h-4 w-2/3 rounded bg-zinc-200 dark:bg-white/[0.08]" />

//                   <div className="mt-2 h-3 w-full rounded bg-zinc-200 dark:bg-white/[0.06]" />

//                   <div className="mt-2 h-3 w-4/5 rounded bg-zinc-200 dark:bg-white/[0.06]" />

//                   <div className="mt-8 border-t border-black/[0.06] dark:border-white/[0.06]" />

//                   <div className="mt-6 h-3 w-1/3 rounded bg-zinc-200 dark:bg-white/[0.06]" />
//                 </div>
//               )
//             )}

//           {/* ====================================================
//               KNOWLEDGE BASE CARDS
//           ===================================================== */}

//           {!loading &&
//             bases.map((base) => (
//               <div
//                 key={base.id}
//                 className="group flex min-h-[280px] flex-col rounded-2xl border border-black/[0.06] bg-white p-5 transition hover:border-cyan-500/30 hover:shadow-md dark:border-white/[0.08] dark:bg-[#101012] dark:hover:border-cyan-400/30"
//               >
//                 {/* TOP */}
//                 <div className="flex items-start justify-between">
//                   <button
//                     type="button"
//                     onClick={() =>
//                       handleOpenKnowledgeBase(base)
//                     }
//                     className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-cyan-500/25 bg-cyan-500/[0.06] transition hover:bg-cyan-500/[0.12]"
//                   >
//                     <Database
//                       size={16}
//                       className="text-cyan-600 dark:text-cyan-400"
//                     />
//                   </button>

//                   {/* STATUS */}
//                   <span className="flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/[0.08] px-2 py-0.5 text-[10px] font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
//                     <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />

//                     {String(
//                       base.status || "active"
//                     ).toUpperCase()}
//                   </span>
//                 </div>

//                 {/* NAME */}
//                 <button
//                   type="button"
//                   onClick={() =>
//                     handleOpenKnowledgeBase(base)
//                   }
//                   className="mt-4 truncate text-left text-[15px] font-semibold text-zinc-900 hover:text-cyan-600 dark:text-zinc-100 dark:hover:text-cyan-400"
//                 >
//                   {base.name}
//                 </button>

//                 {/* ID */}
//                 <p className="mt-1 truncate font-mono text-[10px] text-zinc-400 dark:text-zinc-500">
//                   {base.id}
//                 </p>

//                 {/* DESCRIPTION */}
//                 <p className="mt-2 line-clamp-2 text-[12px] leading-relaxed text-zinc-500 dark:text-zinc-400">
//                   {base.description ||
//                     "No description available."}
//                 </p>

//                 {/* DIVIDER */}
//                 <div className="mt-4 border-t border-black/[0.06] dark:border-white/[0.06]" />

//                 {/* BOTTOM */}
//                 <div className="mt-auto flex items-center justify-between gap-3 pt-4">
//                   {/* SOURCE COUNT */}
//                   <div className="flex items-center gap-1.5 text-[11px] text-zinc-500">
//                     <Folder size={12} />

//                     <span>
//                       {base.sourcesCount} source
//                       {base.sourcesCount !== 1
//                         ? "s"
//                         : ""}
//                     </span>
//                   </div>

//                   {/* UPDATED */}
//                   <div className="flex min-w-0 items-center gap-1.5 text-[11px] text-zinc-400 dark:text-zinc-500">
//                     <Clock
//                       size={11}
//                       className="shrink-0"
//                     />

//                     <span className="truncate">
//                       {formatDate(
//                         base.updated_at
//                       )}
//                     </span>
//                   </div>
//                 </div>

//                 {/* ==================================================
//                     ACTION BUTTONS
//                 =================================================== */}

//                 <div className="mt-4 flex items-center gap-2 border-t border-black/[0.06] pt-3 dark:border-white/[0.06]">
//                   {/* VIEW */}
//                   <button
//                     type="button"
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       handleView(base);
//                     }}
//                     className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-black/[0.08] bg-zinc-50 px-2.5 py-2 text-[11px] font-medium text-zinc-600 transition hover:border-cyan-500/30 hover:bg-cyan-500/[0.05] hover:text-cyan-600 dark:border-white/[0.08] dark:bg-white/[0.02] dark:text-zinc-400 dark:hover:text-cyan-400"
//                   >
//                     <Eye size={13} />
//                     View
//                   </button>

//                   {/* EDIT */}
//                   <button
//                     type="button"
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       handleEdit(base);
//                     }}
//                     className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-black/[0.08] bg-zinc-50 px-2.5 py-2 text-[11px] font-medium text-zinc-600 transition hover:border-amber-500/30 hover:bg-amber-500/[0.05] hover:text-amber-600 dark:border-white/[0.08] dark:bg-white/[0.02] dark:text-zinc-400 dark:hover:text-amber-400"
//                   >
//                     <Pencil size={13} />
//                     Edit
//                   </button>

//                   {/* DELETE */}
//                   <button
//                     type="button"
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       handleDelete(base);
//                     }}
//                     className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-black/[0.08] bg-zinc-50 px-2.5 py-2 text-[11px] font-medium text-zinc-600 transition hover:border-red-500/30 hover:bg-red-500/[0.05] hover:text-red-600 dark:border-white/[0.08] dark:bg-white/[0.02] dark:text-zinc-400 dark:hover:text-red-400"
//                   >
//                     <Trash2 size={13} />
//                     Delete
//                   </button>
//                 </div>
//               </div>
//             ))}

//           {/* ====================================================
//               EMPTY STATE
//           ===================================================== */}

//           {!loading &&
//             !error &&
//             bases.length === 0 && (
//               <div className="min-h-[280px] rounded-2xl border border-black/[0.06] bg-white p-5 dark:border-white/[0.08] dark:bg-[#101012]">
//                 <div className="flex h-full flex-col items-center justify-center text-center">
//                   <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-zinc-100 text-zinc-400 dark:bg-white/[0.05]">
//                     <Database size={19} />
//                   </div>

//                   <p className="mt-4 text-sm font-semibold text-zinc-800 dark:text-zinc-200">
//                     No Knowledge Bases
//                   </p>

//                   <p className="mt-1 max-w-xs text-xs text-zinc-500">
//                     Create your first knowledge base
//                     to provide information for your
//                     AI agents.
//                   </p>
//                 </div>
//               </div>
//             )}
//         </section>
//       </main>

//       {/* ========================================================
//           CREATE KNOWLEDGE BASE
//       ========================================================= */}

//       {showCreate && (
//         <CreateKnowledgeBase
//           onClose={() => setShowCreate(false)}
//           onCreate={handleCreate}
//         />
//       )}

//       {/* ========================================================
//     CREATE SOURCE
// ========================================================= */}

// {showCreateSource && createdKnowledgeBaseId && (
//   <CreateSource
//     knowledgeBaseId={createdKnowledgeBaseId}
//     onClose={() => {
//       setShowCreateSource(false);
//       setCreatedKnowledgeBaseId(null);
//     }}
//     onCreate={(createdSource) => {
//       console.log(
//         "Source created successfully:",
//         createdSource
//       );

//       setShowCreateSource(false);

//       const knowledgeBaseId = createdKnowledgeBaseId;

//       setCreatedKnowledgeBaseId(null);

//       showToast("Source created successfully");

//       // Open Source table page
//       if (knowledgeBaseId) {
//         navigate(
//           `/knowledge-base/${knowledgeBaseId}/sources`
//         );
//       }
//     }}
//   />
// )}

//       {/* ========================================================
//           VIEW KNOWLEDGE BASE
//       ========================================================= */}

//       {showView && selectedKnowledgeBase && (
//         <ViewKnowledgeBase
//           knowledgeBaseId={
//             selectedKnowledgeBase.id
//           }
//           onClose={() => {
//             setShowView(false);
//             setSelectedKnowledgeBase(null);
//           }}
//         />
//       )}

//       {/* ========================================================
//           EDIT KNOWLEDGE BASE
//       ========================================================= */}

//       {showEdit && selectedKnowledgeBase && (
//         <EditKnowledgeBase
//           knowledgeBaseId={
//             selectedKnowledgeBase.id
//           }
//           onClose={() => {
//             setShowEdit(false);
//             setSelectedKnowledgeBase(null);
//           }}
//           onUpdated={handleUpdated}
//         />
//       )}

//       {/* ========================================================
//           DELETE KNOWLEDGE BASE
//       ========================================================= */}

//       {showDelete && selectedKnowledgeBase && (
//         <DeleteKnowledgeBase
//           knowledgeBaseId={
//             selectedKnowledgeBase.id
//           }
//           knowledgeBaseName={
//             selectedKnowledgeBase.name
//           }
//           onClose={() => {
//             setShowDelete(false);
//             setSelectedKnowledgeBase(null);
//           }}
//           onDeleted={handleDeleted}
//         />
//       )}
//     </div>
//   );
// }

// import React, {
//   useCallback,
//   useEffect,
//   useState,
// } from "react";
// import config from "../../../config/Config";
// import { useNavigate } from "react-router-dom";

// import {
//   HelpCircle,
//   Plus,
//   Database,
//   Folder,
//   Clock,
//   Search,
//   ChevronRight,
//   Copy,
//   CheckCircle2,
//   X,
//   Loader2,
// } from "lucide-react";

// import axios from "axios";

// // ============================================================
// // KNOWLEDGE BASE COMPONENTS
// // ============================================================

// import CreateKnowledgeBase from "./CreateKnowledgeBase";
// import CreateSource from "../source/CreateSource";
// import DeleteKnowledgeBase from "./DeleteKnowledgeBase";
// import EditKnowledgeBase from "./EditKnowledgeBase";
// import ViewKnowledgeBase from "./ViewKnowledgeBase";

// export default function KnowledgeBase() {
//   const navigate = useNavigate();

//   // ============================================================
//   // STATES
//   // ============================================================

//   const [bases, setBases] = useState([]);
//   const [total, setTotal] = useState(0);

//   const [loading, setLoading] = useState(true);
//   const [refreshing, setRefreshing] = useState(false);

//   const [toast, setToast] = useState(null);
//   const [error, setError] = useState("");
//   const [searchTerm, setSearchTerm] = useState("");
//   const [copiedId, setCopiedId] = useState(null);

//   const [showCreateSource, setShowCreateSource] = useState(false);
//   const [createdKnowledgeBaseId, setCreatedKnowledgeBaseId] = useState(null);

//   // ============================================================
//   // MODAL STATES
//   // ============================================================

//   const [showCreate, setShowCreate] = useState(false);
//   const [showView, setShowView] = useState(false);
//   const [showEdit, setShowEdit] = useState(false);
//   const [showDelete, setShowDelete] = useState(false);

//   const [selectedKnowledgeBase, setSelectedKnowledgeBase] = useState(null);

//   // ============================================================
//   // GET KNOWLEDGE BASES
//   // ============================================================

//   const fetchKnowledgeBases = useCallback(
//     async (showLoader = true) => {
//       try {
//         if (showLoader) setLoading(true);
//         else setRefreshing(true);

//         setError("");

//         const response = await axios.get(`${config.BASE_URL}/knowledge-bases`, {
//           headers: { Accept: "*/*" },
//         });

//         const items = Array.isArray(response.data?.items)
//           ? response.data.items
//           : [];

//         const formattedBases = items.map((base) => ({
//           id: base.id,
//           name: base.name || "Untitled",
//           description: base.description || "",
//           status: base.status || "active",
//           created_at: base.created_at,
//           updated_at: base.updated_at,
//           uuid: base.id,
//           sourcesCount: 1, // Hardcoded for demo matching screenshot, replace with actual data if available
//         }));

//         setBases(formattedBases);
//         setTotal(
//           typeof response.data?.total === "number"
//             ? response.data.total
//             : formattedBases.length
//         );
//       } catch (err) {
//         console.error("Get Knowledge Bases Error:", err);
//         const message =
//           err?.response?.data?.detail ||
//           err?.response?.data?.message ||
//           "Failed to load knowledge bases.";
//         setError(message);
//         setBases([]);
//         setTotal(0);
//       } finally {
//         setLoading(false);
//         setRefreshing(false);
//       }
//     },
//     []
//   );

//   useEffect(() => {
//     fetchKnowledgeBases();
//   }, [fetchKnowledgeBases]);

//   // ============================================================
//   // HELPERS
//   // ============================================================

//   const formatRelativeTime = (dateString) => {
//     if (!dateString) return "Just now";
//     try {
//       const date = new Date(dateString);
//       const now = new Date();
//       const diffInMinutes = Math.floor((now - date) / 60000);

//       if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
//       if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
//       return `${Math.floor(diffInMinutes / 1440)}d ago`;
//     } catch {
//       return "Recently";
//     }
//   };

//   const handleCopyId = async (e, id) => {
//     e.stopPropagation();
//     try {
//       await navigator.clipboard.writeText(id);
//       setCopiedId(id);
//       setTimeout(() => setCopiedId(null), 1500);
//     } catch (err) {
//       console.error("Copy failed:", err);
//     }
//   };

//   const showToast = (message) => {
//     setToast(message);
//     setTimeout(() => setToast(null), 3000);
//   };

//   const handleCreate = async (createdKnowledgeBase) => {
//     setShowCreate(false);
//     if (!createdKnowledgeBase?.id) {
//       showToast("Knowledge base created, but ID was not returned.");
//       return;
//     }
//     setCreatedKnowledgeBaseId(createdKnowledgeBase.id);
//     await fetchKnowledgeBases(false);
//     showToast("Knowledge base created successfully");
//     setTimeout(() => setShowCreateSource(true), 300);
//   };

//   const handleOpenKnowledgeBase = (base) => {
//     if (!base?.id) return;
//     navigate(`/knowledge-base/${base.id}`);
//   };

//   const handleUpdated = async (updatedKnowledgeBase) => {
//     setShowEdit(false);
//     setSelectedKnowledgeBase(null);
//     await fetchKnowledgeBases(false);
//     showToast("Knowledge base updated successfully");
//   };

//   const handleDeleted = async () => {
//     setShowDelete(false);
//     setSelectedKnowledgeBase(null);
//     await fetchKnowledgeBases(false);
//     showToast("Knowledge base deleted successfully");
//   };

//   // Filter bases based on search
//   const filteredBases = bases.filter((base) =>
//     base.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
//     base.id.toLowerCase().includes(searchTerm.toLowerCase())
//   );

//   // ============================================================
//   // UI
//   // ============================================================

//   return (
//     <div className="min-h-screen bg-white text-gray-900">
//       {/* TOAST */}
//       {toast && (
//         <div className="fixed right-6 top-6 z-[100] flex min-w-[280px] items-center gap-3 overflow-hidden rounded-xl border border-emerald-500/30 bg-white shadow-xl">
//           <div className="flex flex-1 items-center gap-3 px-4 py-3">
//             <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-500">
//               <CheckCircle2 size={16} />
//             </div>
//             <span className="text-sm font-medium text-gray-800">{toast}</span>
//           </div>
//         </div>
//       )}

//       <main className="mx-auto max-w-[1600px] p-6 lg:p-8">
       

//         {/* ERROR */}
//         {error && (
//           <div className="mb-6 flex items-center justify-between rounded-lg border border-red-200 bg-red-50 px-4 py-3">
//             <p className="text-sm font-medium text-red-600">{error}</p>
//             <button
//               onClick={() => fetchKnowledgeBases()}
//               className="rounded bg-red-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-red-700"
//             >
//               Retry
//             </button>
//           </div>
//         )}

//         {/* GRID */}
//         <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          
//           {/* CREATE CARD */}
//           <button
//             type="button"
//             onClick={() => setShowCreate(true)}
//             className="group flex min-h-[280px] flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-gray-300 bg-gray-50/50 p-5 transition hover:border-cyan-400 hover:bg-cyan-50/30"
//           >
//             <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-gray-200 bg-white text-gray-400 shadow-sm transition group-hover:border-cyan-200 group-hover:text-cyan-600">
//               <Plus size={22} />
//             </div>
//             <div className="text-center">
//               <p className="text-sm font-semibold text-gray-800 group-hover:text-cyan-700">
//                 Create Knowledge Base
//               </p>
//               <p className="mt-1 text-xs text-gray-500">
//                 Add sources for agents
//               </p>
//             </div>
//           </button>

//           {/* LOADING SKELETONS */}
//           {loading &&
//             Array.from({ length: 3 }).map((_, index) => (
//               <div
//                 key={`skeleton-${index}`}
//                 className="min-h-[280px] animate-pulse rounded-xl border border-gray-200 bg-white p-5"
//               >
//                 <div className="h-10 w-10 rounded-lg bg-gray-200" />
//                 <div className="mt-5 h-4 w-2/3 rounded bg-gray-200" />
//                 <div className="mt-2 h-3 w-1/2 rounded bg-gray-200" />
//                 <div className="mt-8 border-t border-gray-100" />
//                 <div className="mt-6 flex justify-between">
//                   <div className="h-3 w-1/4 rounded bg-gray-200" />
//                   <div className="h-3 w-1/4 rounded bg-gray-200" />
//                 </div>
//               </div>
//             ))}

//           {/* KNOWLEDGE BASE CARDS */}
//           {!loading &&
//             filteredBases.map((base) => (
//               <div
//                 key={base.id}
//                 onClick={() => handleOpenKnowledgeBase(base)}
//                 className="group relative flex min-h-[280px] cursor-pointer flex-col rounded-xl border border-gray-200 bg-white p-5 transition hover:border-cyan-300 hover:shadow-md"
//               >
//                 {/* TOP: Icon & Status */}
//                 <div className="flex items-start justify-between">
//                   <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-cyan-100 bg-cyan-50">
//                     <Database size={18} className="text-cyan-600" />
//                   </div>
//                   <span className="flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-[10px] font-bold tracking-wider text-emerald-600">
//                     <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
//                     READY
//                   </span>
//                 </div>

//                 {/* NAME */}
//                 <h3 className="mt-4 truncate text-base font-semibold text-gray-900">
//                   {base.name}
//                 </h3>

//                 {/* ID */}
//                 <p className="mt-1 truncate font-mono text-[11px] text-gray-400">
//                   {base.id}
//                 </p>

//                 {/* DIVIDER */}
//                 <div className="mt-4 border-t border-gray-100" />

//                 {/* BOTTOM: Source Count & Time */}
//                 <div className="mt-auto flex items-center justify-between pt-4">
//                   <div className="flex items-center gap-1.5 text-xs text-gray-500">
//                     <Folder size={13} />
//                     <span>{base.sourcesCount} source{base.sourcesCount !== 1 ? "s" : ""}</span>
//                   </div>
//                   <div className="flex items-center gap-1.5 text-xs text-gray-400">
//                     <Clock size={12} />
//                     <span>{formatRelativeTime(base.updated_at)}</span>
//                   </div>
//                 </div>

//                 {/* CHEVRON (Right side) */}
//                 <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300 opacity-0 transition group-hover:opacity-100">
//                   <ChevronRight size={20} />
//                 </div>
//               </div>
//             ))}

//           {/* EMPTY STATE */}
//           {!loading && !error && filteredBases.length === 0 && searchTerm && (
//             <div className="col-span-full flex flex-col items-center justify-center rounded-xl border border-gray-200 bg-white py-16 text-center">
//               <Search size={24} className="text-gray-300" />
//               <p className="mt-4 text-sm font-medium text-gray-900">No knowledge bases found</p>
//               <p className="mt-1 text-xs text-gray-500">Try adjusting your search terms.</p>
//             </div>
//           )}
//         </div>
//       </main>

//       {/* MODALS */}
//       {showCreate && (
//         <CreateKnowledgeBase
//           onClose={() => setShowCreate(false)}
//           onCreate={handleCreate}
//         />
//       )}

//       {showCreateSource && createdKnowledgeBaseId && (
//         <CreateSource
//           knowledgeBaseId={createdKnowledgeBaseId}
//           onClose={() => {
//             setShowCreateSource(false);
//             setCreatedKnowledgeBaseId(null);
//           }}
//           onCreate={() => {
//             setShowCreateSource(false);
//             const kbId = createdKnowledgeBaseId;
//             setCreatedKnowledgeBaseId(null);
//             showToast("Source created successfully");
//             if (kbId) navigate(`/knowledge-base/${kbId}/sources`);
//           }}
//         />
//       )}

//       {showView && selectedKnowledgeBase && (
//         <ViewKnowledgeBase
//           knowledgeBaseId={selectedKnowledgeBase.id}
//           onClose={() => {
//             setShowView(false);
//             setSelectedKnowledgeBase(null);
//           }}
//         />
//       )}

//       {showEdit && selectedKnowledgeBase && (
//         <EditKnowledgeBase
//           knowledgeBaseId={selectedKnowledgeBase.id}
//           onClose={() => {
//             setShowEdit(false);
//             setSelectedKnowledgeBase(null);
//           }}
//           onUpdated={handleUpdated}
//         />
//       )}

//       {showDelete && selectedKnowledgeBase && (
//         <DeleteKnowledgeBase
//           knowledgeBaseId={selectedKnowledgeBase.id}
//           knowledgeBaseName={selectedKnowledgeBase.name}
//           onClose={() => {
//             setShowDelete(false);
//             setSelectedKnowledgeBase(null);
//           }}
//           onDeleted={handleDeleted}
//         />
//       )}
//     </div>
//   );
// }

// import React, { useCallback, useEffect, useMemo, useState } from "react";
// import config from "../../../config/Config";
// import { useNavigate } from "react-router-dom";
// import {
//   Database,
//   Folder,
//   Clock,
//   Plus,
//   Search,
//   ChevronRight,
//   CheckCircle2,
// } from "lucide-react";
// import axios from "axios";

// import CreateKnowledgeBase from "./CreateKnowledgeBase";
// import CreateSource from "../source/CreateSource";
// import DeleteKnowledgeBase from "./DeleteKnowledgeBase";
// import EditKnowledgeBase from "./EditKnowledgeBase";
// import ViewKnowledgeBase from "./ViewKnowledgeBase";

// /**
//  * Knowledge Base
//  *
//  * Important:
//  * The global Header owns the theme toggle.
//  * This page intentionally does NOT render another toggle.
//  *
//  * To make the page work with both Tailwind v3 and Tailwind v4,
//  * the page reads the `dark` class / theme attributes from <html>/<body>
//  * instead of depending only on Tailwind's `dark:` variant.
//  */
// export default function KnowledgeBase() {
//   const navigate = useNavigate();

//   const [bases, setBases] = useState([]);
//   const [total, setTotal] = useState(0);

//   const [loading, setLoading] = useState(true);
//   const [refreshing, setRefreshing] = useState(false);

//   const [toast, setToast] = useState(null);
//   const [error, setError] = useState("");

//   const [showCreateSource, setShowCreateSource] = useState(false);
//   const [createdKnowledgeBaseId, setCreatedKnowledgeBaseId] = useState(null);

//   const [showCreate, setShowCreate] = useState(false);
//   const [showView, setShowView] = useState(false);
//   const [showEdit, setShowEdit] = useState(false);
//   const [showDelete, setShowDelete] = useState(false);

//   const [selectedKnowledgeBase, setSelectedKnowledgeBase] = useState(null);

//   // ------------------------------------------------------------
//   // THEME
//   // ------------------------------------------------------------
//   const getIsDark = useCallback(() => {
//     if (typeof document === "undefined") return false;

//     const html = document.documentElement;
//     const body = document.body;

//     const storedTheme =
//       typeof localStorage !== "undefined"
//         ? localStorage.getItem("theme") ||
//           localStorage.getItem("ravanai_theme") ||
//           localStorage.getItem("color-theme")
//         : null;

//     return (
//       html.classList.contains("dark") ||
//       body?.classList.contains("dark") ||
//       html.dataset.theme === "dark" ||
//       body?.dataset.theme === "dark" ||
//       html.getAttribute("data-theme") === "dark" ||
//       body?.getAttribute("data-theme") === "dark" ||
//       storedTheme === "dark"
//     );
//   }, []);

//   const [isDark, setIsDark] = useState(() => getIsDark());

//   useEffect(() => {
//     if (typeof document === "undefined") return undefined;

//     const syncTheme = () => {
//       setIsDark(getIsDark());
//     };

//     syncTheme();

//     const htmlObserver = new MutationObserver(syncTheme);
//     const bodyObserver = new MutationObserver(syncTheme);

//     htmlObserver.observe(document.documentElement, {
//       attributes: true,
//       attributeFilter: ["class", "data-theme"],
//     });

//     if (document.body) {
//       bodyObserver.observe(document.body, {
//         attributes: true,
//         attributeFilter: ["class", "data-theme"],
//       });
//     }

//     window.addEventListener("storage", syncTheme);

//     // Fallback for theme providers that update localStorage/state
//     // without changing an observed DOM attribute immediately.
//     const interval = window.setInterval(syncTheme, 300);

//     return () => {
//       htmlObserver.disconnect();
//       bodyObserver.disconnect();
//       window.removeEventListener("storage", syncTheme);
//       window.clearInterval(interval);
//     };
//   }, [getIsDark]);

//   // Theme-dependent classes are explicit so this page works even if
//   // Tailwind's dark variant is not configured correctly.
//   const theme = useMemo(
//     () => ({
//       page: isDark
//         ? "bg-[#09090b] text-zinc-100"
//         : "bg-white text-zinc-900",

//       card: isDark
//         ? "border-white/[0.08] bg-[#101012] hover:border-cyan-400/30"
//         : "border-gray-200 bg-white hover:border-cyan-300",

//       createCard: isDark
//         ? "border-white/[0.10] bg-white/[0.02] hover:border-cyan-400/40 hover:bg-cyan-500/[0.03]"
//         : "border-gray-300 bg-gray-50/50 hover:border-cyan-400 hover:bg-cyan-50/30",

//       createIcon: isDark
//         ? "border-white/[0.08] bg-white/[0.05] text-zinc-400 group-hover:text-cyan-400"
//         : "border-gray-200 bg-white text-gray-400 group-hover:border-cyan-200 group-hover:text-cyan-600",

//       primaryText: isDark ? "text-zinc-100" : "text-gray-900",
//       secondaryText: isDark ? "text-zinc-400" : "text-gray-500",
//       mutedText: isDark ? "text-zinc-500" : "text-gray-400",

//       divider: isDark ? "border-white/[0.06]" : "border-gray-100",

//       skeleton: isDark
//         ? "border-white/[0.08] bg-[#101012]"
//         : "border-gray-200 bg-white",

//       skeletonBlock: isDark ? "bg-white/[0.08]" : "bg-gray-200",

//       empty: isDark
//         ? "border-white/[0.08] bg-[#101012]"
//         : "border-gray-200 bg-white",

//       toast: isDark
//         ? "border-emerald-500/30 bg-[#101012]"
//         : "border-emerald-500/30 bg-white",
//     }),
//     [isDark]
//   );

//   // ------------------------------------------------------------
//   // GET KNOWLEDGE BASES
//   // ------------------------------------------------------------
//   const fetchKnowledgeBases = useCallback(async (showLoader = true) => {
//     try {
//       if (showLoader) {
//         setLoading(true);
//       } else {
//         setRefreshing(true);
//       }

//       setError("");

//       const response = await axios.get(
//         `${config.BASE_URL}/knowledge-bases`,
//         {
//           headers: {
//             Accept: "*/*",
//           },
//         }
//       );

//       const items = Array.isArray(response.data?.items)
//         ? response.data.items
//         : [];

//       const formattedBases = items.map((base) => ({
//         id: base.id,
//         name: base.name || "Untitled",
//         description: base.description || "",
//         status: base.status || "active",
//         created_at: base.created_at,
//         updated_at: base.updated_at,
//         uuid: base.id,
//         // Keep your current UI behaviour.
//         sourcesCount: 1,
//       }));

//       setBases(formattedBases);

//       setTotal(
//         typeof response.data?.total === "number"
//           ? response.data.total
//           : formattedBases.length
//       );
//     } catch (err) {
//       console.error("Get Knowledge Bases Error:", err);

//       const message =
//         err?.response?.data?.detail ||
//         err?.response?.data?.message ||
//         "Failed to load knowledge bases.";

//       setError(message);
//       setBases([]);
//       setTotal(0);
//     } finally {
//       setLoading(false);
//       setRefreshing(false);
//     }
//   }, []);

//   useEffect(() => {
//     fetchKnowledgeBases();
//   }, [fetchKnowledgeBases]);

//   // ------------------------------------------------------------
//   // HELPERS
//   // ------------------------------------------------------------
//   const formatRelativeTime = (dateString) => {
//     if (!dateString) return "Just now";

//     try {
//       const date = new Date(dateString);

//       if (Number.isNaN(date.getTime())) {
//         return "Recently";
//       }

//       const now = new Date();
//       const diffInMinutes = Math.max(
//         0,
//         Math.floor((now - date) / 60000)
//       );

//       if (diffInMinutes < 1) return "Just now";
//       if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
//       if (diffInMinutes < 1440) {
//         return `${Math.floor(diffInMinutes / 60)}h ago`;
//       }

//       return `${Math.floor(diffInMinutes / 1440)}d ago`;
//     } catch {
//       return "Recently";
//     }
//   };

//   const showToast = (message) => {
//     setToast(message);

//     window.setTimeout(() => {
//       setToast(null);
//     }, 3000);
//   };

//   // ------------------------------------------------------------
//   // CREATE
//   // ------------------------------------------------------------
//   const handleCreate = async (createdKnowledgeBase) => {
//     setShowCreate(false);

//     if (!createdKnowledgeBase?.id) {
//       showToast("Knowledge base created, but ID was not returned.");
//       return;
//     }

//     setCreatedKnowledgeBaseId(createdKnowledgeBase.id);

//     await fetchKnowledgeBases(false);

//     showToast("Knowledge base created successfully");

//     window.setTimeout(() => {
//       setShowCreateSource(true);
//     }, 300);
//   };

//   // ------------------------------------------------------------
//   // OPEN DETAILS
//   // ------------------------------------------------------------
//   const handleOpenKnowledgeBase = (base) => {
//     if (!base?.id) return;

//     navigate(`/knowledge-base/${base.id}`);
//   };

//   // ------------------------------------------------------------
//   // UPDATE
//   // ------------------------------------------------------------
//   const handleUpdated = async () => {
//     setShowEdit(false);
//     setSelectedKnowledgeBase(null);

//     await fetchKnowledgeBases(false);

//     showToast("Knowledge base updated successfully");
//   };

//   // ------------------------------------------------------------
//   // DELETE
//   // ------------------------------------------------------------
//   const handleDeleted = async () => {
//     setShowDelete(false);
//     setSelectedKnowledgeBase(null);

//     await fetchKnowledgeBases(false);

//     showToast("Knowledge base deleted successfully");
//   };

//   // ------------------------------------------------------------
//   // REFRESH
//   // ------------------------------------------------------------
//   const handleRefresh = async () => {
//     await fetchKnowledgeBases(false);
//     showToast("Knowledge bases refreshed");
//   };

//   // ------------------------------------------------------------
//   // UI
//   // ------------------------------------------------------------
//   return (
//     <div
//       className={`min-h-screen w-full transition-colors duration-200 ${theme.page}`}
//     >
//       {/* ========================================================
//           TOAST
//       ========================================================= */}
//       {toast && (
//         <div
//           className={`fixed right-6 top-6 z-[100] flex min-w-[280px] items-center gap-3 overflow-hidden rounded-xl border shadow-xl ${theme.toast}`}
//         >
//           <div className="flex flex-1 items-center gap-3 px-4 py-3">
//             <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-500">
//               <CheckCircle2 size={16} />
//             </div>

//             <span
//               className={`text-sm font-medium ${
//                 isDark ? "text-zinc-200" : "text-gray-800"
//               }`}
//             >
//               {toast}
//             </span>
//           </div>
//         </div>
//       )}

//       <main className="mx-auto max-w-[1600px] p-6 lg:p-8">
//         {/* ======================================================
//             PAGE CONTENT
//         ======================================================= */}

//         {/* ERROR */}
//         {error && (
//           <div
//             className={`mb-6 flex items-center justify-between rounded-lg border px-4 py-3 ${
//               isDark
//                 ? "border-red-500/20 bg-red-500/[0.06]"
//                 : "border-red-200 bg-red-50"
//             }`}
//           >
//             <p
//               className={`text-sm font-medium ${
//                 isDark ? "text-red-400" : "text-red-600"
//               }`}
//             >
//               {error}
//             </p>

//             <button
//               type="button"
//               onClick={() => fetchKnowledgeBases()}
//               className="rounded bg-red-600 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-red-700"
//             >
//               Retry
//             </button>
//           </div>
//         )}

//         {/* GRID */}
//         <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
//           {/* ====================================================
//               CREATE KNOWLEDGE BASE
//           ===================================================== */}
//           <button
//             type="button"
//             onClick={() => setShowCreate(true)}
//             className={`group flex min-h-[280px] flex-col items-center justify-center gap-3 rounded-xl border border-dashed p-5 transition ${theme.createCard}`}
//           >
//             <div
//               className={`flex h-12 w-12 items-center justify-center rounded-xl border shadow-sm transition ${theme.createIcon}`}
//             >
//               <Plus size={22} />
//             </div>

//             <div className="text-center">
//               <p
//                 className={`text-sm font-semibold ${
//                   isDark
//                     ? "text-zinc-200 group-hover:text-cyan-400"
//                     : "text-gray-800 group-hover:text-cyan-700"
//                 }`}
//               >
//                 Create Knowledge Base
//               </p>

//               <p className={`mt-1 text-xs ${theme.secondaryText}`}>
//                 Add sources for agents
//               </p>
//             </div>
//           </button>

//           {/* ====================================================
//               LOADING SKELETONS
//           ===================================================== */}
//           {loading &&
//             Array.from({ length: 3 }).map((_, index) => (
//               <div
//                 key={`skeleton-${index}`}
//                 className={`min-h-[280px] animate-pulse rounded-xl border p-5 ${theme.skeleton}`}
//               >
//                 <div
//                   className={`h-10 w-10 rounded-lg ${theme.skeletonBlock}`}
//                 />

//                 <div
//                   className={`mt-5 h-4 w-2/3 rounded ${theme.skeletonBlock}`}
//                 />

//                 <div
//                   className={`mt-2 h-3 w-1/2 rounded ${theme.skeletonBlock}`}
//                 />

//                 <div
//                   className={`mt-8 border-t ${theme.divider}`}
//                 />

//                 <div className="mt-6 flex justify-between">
//                   <div
//                     className={`h-3 w-1/4 rounded ${theme.skeletonBlock}`}
//                   />
//                   <div
//                     className={`h-3 w-1/4 rounded ${theme.skeletonBlock}`}
//                   />
//                 </div>
//               </div>
//             ))}

//           {/* ====================================================
//               KNOWLEDGE BASE CARDS
//           ===================================================== */}
//           {!loading &&
//             bases.map((base) => (
//               <div
//                 key={base.id}
//                 onClick={() => handleOpenKnowledgeBase(base)}
//                 role="button"
//                 tabIndex={0}
//                 onKeyDown={(event) => {
//                   if (event.key === "Enter" || event.key === " ") {
//                     event.preventDefault();
//                     handleOpenKnowledgeBase(base);
//                   }
//                 }}
//                 className={`group relative flex min-h-[280px] cursor-pointer flex-col rounded-xl border p-5 transition hover:shadow-md ${theme.card}`}
//               >
//                 {/* TOP: ICON + STATUS */}
//                 <div className="flex items-start justify-between">
//                   <div
//                     className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border ${
//                       isDark
//                         ? "border-cyan-400/20 bg-cyan-400/[0.06]"
//                         : "border-cyan-100 bg-cyan-50"
//                     }`}
//                   >
//                     <Database
//                       size={18}
//                       className={
//                         isDark ? "text-cyan-400" : "text-cyan-600"
//                       }
//                     />
//                   </div>

//                   <span className="flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-[10px] font-bold tracking-wider text-emerald-600">
//                     <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
//                     READY
//                   </span>
//                 </div>

//                 {/* NAME */}
//                 <h3
//                   className={`mt-4 truncate text-base font-semibold ${theme.primaryText}`}
//                 >
//                   {base.name}
//                 </h3>

//                 {/* ID */}
//                 <p
//                   className={`mt-1 truncate font-mono text-[11px] ${theme.mutedText}`}
//                 >
//                   {base.id}
//                 </p>

//                 {/* DIVIDER */}
//                 <div className={`mt-4 border-t ${theme.divider}`} />

//                 {/* BOTTOM */}
//                 <div className="mt-auto flex items-center justify-between pt-4">
//                   <div
//                     className={`flex items-center gap-1.5 text-xs ${theme.secondaryText}`}
//                   >
//                     <Folder size={13} />
//                     <span>
//                       {base.sourcesCount} source
//                       {base.sourcesCount !== 1 ? "s" : ""}
//                     </span>
//                   </div>

//                   <div
//                     className={`flex items-center gap-1.5 text-xs ${theme.mutedText}`}
//                   >
//                     <Clock size={12} />
//                     <span>
//                       {formatRelativeTime(base.updated_at)}
//                     </span>
//                   </div>
//                 </div>

//                 {/* HOVER CHEVRON */}
//                 <div
//                   className={`absolute right-4 top-1/2 -translate-y-1/2 opacity-0 transition group-hover:opacity-100 ${
//                     isDark ? "text-zinc-600" : "text-gray-300"
//                   }`}
//                 >
//                   <ChevronRight size={20} />
//                 </div>
//               </div>
//             ))}

//           {/* ====================================================
//               EMPTY SEARCH STATE
//           ===================================================== */}
//           {!loading && !error && bases.length === 0 && (
//             <div
//               className={`col-span-full flex min-h-[280px] flex-col items-center justify-center rounded-xl border py-16 text-center ${theme.empty}`}
//             >
//               <div
//                 className={`flex h-12 w-12 items-center justify-center rounded-xl ${
//                   isDark
//                     ? "bg-white/[0.05] text-zinc-500"
//                     : "bg-gray-100 text-gray-400"
//                 }`}
//               >
//                 <Database size={20} />
//               </div>

//               <p
//                 className={`mt-4 text-sm font-semibold ${theme.primaryText}`}
//               >
//                 No Knowledge Bases
//               </p>

//               <p
//                 className={`mt-1 max-w-sm text-xs ${theme.secondaryText}`}
//               >
//                 Create your first knowledge base to provide information
//                 for your AI agents.
//               </p>
//             </div>
//           )}
//         </div>
//       </main>

//       {/* ========================================================
//           CREATE KNOWLEDGE BASE
//       ========================================================= */}
//       {showCreate && (
//         <CreateKnowledgeBase
//           onClose={() => setShowCreate(false)}
//           onCreate={handleCreate}
//         />
//       )}

//       {/* ========================================================
//           CREATE SOURCE
//       ========================================================= */}
//       {showCreateSource && createdKnowledgeBaseId && (
//         <CreateSource
//           knowledgeBaseId={createdKnowledgeBaseId}
//           onClose={() => {
//             setShowCreateSource(false);
//             setCreatedKnowledgeBaseId(null);
//           }}
//           onCreate={() => {
//             setShowCreateSource(false);

//             const knowledgeBaseId = createdKnowledgeBaseId;

//             setCreatedKnowledgeBaseId(null);

//             showToast("Source created successfully");

//             if (knowledgeBaseId) {
//               navigate(`/knowledge-base/${knowledgeBaseId}/sources`);
//             }
//           }}
//         />
//       )}

//       {/* ========================================================
//           VIEW KNOWLEDGE BASE
//       ========================================================= */}
//       {showView && selectedKnowledgeBase && (
//         <ViewKnowledgeBase
//           knowledgeBaseId={selectedKnowledgeBase.id}
//           onClose={() => {
//             setShowView(false);
//             setSelectedKnowledgeBase(null);
//           }}
//         />
//       )}

//       {/* ========================================================
//           EDIT KNOWLEDGE BASE
//       ========================================================= */}
//       {showEdit && selectedKnowledgeBase && (
//         <EditKnowledgeBase
//           knowledgeBaseId={selectedKnowledgeBase.id}
//           onClose={() => {
//             setShowEdit(false);
//             setSelectedKnowledgeBase(null);
//           }}
//           onUpdated={handleUpdated}
//         />
//       )}

//       {/* ========================================================
//           DELETE KNOWLEDGE BASE
//       ========================================================= */}
//       {showDelete && selectedKnowledgeBase && (
//         <DeleteKnowledgeBase
//           knowledgeBaseId={selectedKnowledgeBase.id}
//           knowledgeBaseName={selectedKnowledgeBase.name}
//           onClose={() => {
//             setShowDelete(false);
//             setSelectedKnowledgeBase(null);
//           }}
//           onDeleted={handleDeleted}
//         />
//       )}
//     </div>
//   );
// }


import React, { useCallback, useEffect, useMemo, useState } from "react";
import config from "../../../config/Config";
import { useNavigate } from "react-router-dom";
import {
  Database,
  Folder,
  Clock,
  Plus,
  Search,
  ChevronRight,
  CheckCircle2,
  Bell,
  Settings,
  MoreVertical,
} from "lucide-react";
import axios from "axios";

import CreateKnowledgeBase from "./CreateKnowledgeBase";
import CreateSource from "../source/CreateSource";
import DeleteKnowledgeBase from "./DeleteKnowledgeBase";
import EditKnowledgeBase from "./EditKnowledgeBase";
import ViewKnowledgeBase from "./ViewKnowledgeBase";

export default function KnowledgeBase() {
  const navigate = useNavigate();

  const [bases, setBases] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [toast, setToast] = useState(null);
  const [error, setError] = useState("");

  const [showCreateSource, setShowCreateSource] = useState(false);
  const [createdKnowledgeBaseId, setCreatedKnowledgeBaseId] = useState(null);
  const [showCreate, setShowCreate] = useState(false);
  const [showView, setShowView] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [selectedKnowledgeBase, setSelectedKnowledgeBase] = useState(null);

  // ------------------------------------------------------------
  // THEME
  // ------------------------------------------------------------
  const getIsDark = useCallback(() => {
    if (typeof document === "undefined") return true; // Force dark by default for exact look

    const html = document.documentElement;
    const body = document.body;

    const storedTheme =
      typeof localStorage !== "undefined"
        ? localStorage.getItem("theme") ||
          localStorage.getItem("ravanai_theme") ||
          localStorage.getItem("color-theme")
        : null;

    return (
      html.classList.contains("dark") ||
      body?.classList.contains("dark") ||
      html.dataset.theme === "dark" ||
      body?.dataset.theme === "dark" ||
      html.getAttribute("data-theme") === "dark" ||
      body?.getAttribute("data-theme") === "dark" ||
      storedTheme === "dark"
    );
  }, []);

  const [isDark, setIsDark] = useState(() => getIsDark());

  useEffect(() => {
    if (typeof document === "undefined") return undefined;

    const syncTheme = () => {
      setIsDark(getIsDark());
    };

    syncTheme();

    const htmlObserver = new MutationObserver(syncTheme);
    const bodyObserver = new MutationObserver(syncTheme);

    htmlObserver.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class", "data-theme"],
    });

    if (document.body) {
      bodyObserver.observe(document.body, {
        attributes: true,
        attributeFilter: ["class", "data-theme"],
      });
    }

    window.addEventListener("storage", syncTheme);
    const interval = window.setInterval(syncTheme, 300);

    return () => {
      htmlObserver.disconnect();
      bodyObserver.disconnect();
      window.removeEventListener("storage", syncTheme);
      window.clearInterval(interval);
    };
  }, [getIsDark]);

  // Exact dark theme matching the screenshot
  const theme = useMemo(
    () => ({
      page: "bg-[#09090b] text-zinc-100",
      card: "border-white/[0.08] bg-[#101012] hover:border-cyan-400/30",
      createCard:
        "border-white/[0.10] bg-white/[0.02] hover:border-cyan-400/40 hover:bg-cyan-500/[0.03]",
      createIcon:
        "border-white/[0.08] bg-white/[0.05] text-zinc-400 group-hover:text-cyan-400",
      primaryText: "text-zinc-100",
      secondaryText: "text-zinc-400",
      mutedText: "text-zinc-500",
      divider: "border-white/[0.06]",
      skeleton: "border-white/[0.08] bg-[#101012]",
      skeletonBlock: "bg-white/[0.08]",
      empty: "border-white/[0.08] bg-[#101012]",
      toast: "border-emerald-500/30 bg-[#101012]",
    }),
    []
  );

  // ------------------------------------------------------------
  // GET KNOWLEDGE BASES
  // ------------------------------------------------------------
  const fetchKnowledgeBases = useCallback(async (showLoader = true) => {
    try {
      if (showLoader) setLoading(true);
      else setRefreshing(true);

      setError("");

      const response = await axios.get(`${config.BASE_URL}/knowledge-bases`, {
        headers: { Accept: "*/*" },
      });

      const items = Array.isArray(response.data?.items) ? response.data.items : [];

      const formattedBases = items.map((base) => ({
        id: base.id,
        name: base.name || "Untitled",
        description: base.description || "",
        status: base.status || "active",
        created_at: base.created_at,
        updated_at: base.updated_at,
        uuid: base.id,
        sourcesCount: 0,
      }));

      setBases(formattedBases);
      setTotal(
        typeof response.data?.total === "number"
          ? response.data.total
          : formattedBases.length
      );
    } catch (err) {
      console.error("Get Knowledge Bases Error:", err);
      const message =
        err?.response?.data?.detail ||
        err?.response?.data?.message ||
        "Failed to load knowledge bases.";
      setError(message);
      setBases([]);
      setTotal(0);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchKnowledgeBases();
  }, [fetchKnowledgeBases]);

  // ------------------------------------------------------------
  // HELPERS
  // ------------------------------------------------------------
  const formatRelativeTime = (dateString) => {
    if (!dateString) return "Just now";
    try {
      const date = new Date(dateString);
      if (Number.isNaN(date.getTime())) return "Recently";
      const now = new Date();
      const diffInMinutes = Math.max(0, Math.floor((now - date) / 60000));
      if (diffInMinutes < 1) return "Just now";
      if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
      if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
      return `${Math.floor(diffInMinutes / 1440)}d ago`;
    } catch {
      return "Recently";
    }
  };

  const showToast = (message) => {
    setToast(message);
    window.setTimeout(() => setToast(null), 3000);
  };

  const handleCreate = async (createdKnowledgeBase) => {
    setShowCreate(false);
    if (!createdKnowledgeBase?.id) {
      showToast("Knowledge base created, but ID was not returned.");
      return;
    }
    setCreatedKnowledgeBaseId(createdKnowledgeBase.id);
    await fetchKnowledgeBases(false);
    showToast("Knowledge base created successfully");
    window.setTimeout(() => setShowCreateSource(true), 300);
  };

  const handleOpenKnowledgeBase = (base) => {
    if (!base?.id) return;
    navigate(`/knowledge-base/${base.id}`);
  };

  const handleUpdated = async () => {
    setShowEdit(false);
    setSelectedKnowledgeBase(null);
    await fetchKnowledgeBases(false);
    showToast("Knowledge base updated successfully");
  };

  const handleDeleted = async () => {
    setShowDelete(false);
    setSelectedKnowledgeBase(null);
    await fetchKnowledgeBases(false);
    showToast("Knowledge base deleted successfully");
  };

  // ------------------------------------------------------------
  // UI
  // ------------------------------------------------------------
  return (
    <div className={`min-h-screen w-full transition-colors duration-200 ${theme.page}`}>
      {/* TOAST */}
      {toast && (
        <div
          className={`fixed right-6 top-6 z-[100] flex min-w-[280px] items-center gap-3 overflow-hidden rounded-xl border shadow-xl ${theme.toast}`}
        >
          <div className="flex flex-1 items-center gap-3 px-4 py-3">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-500">
              <CheckCircle2 size={16} />
            </div>
            <span className="text-sm font-medium text-zinc-200">{toast}</span>
          </div>
        </div>
      )}

    

      {/* MAIN CONTENT */}
      <main className="mx-auto max-w-[1600px] p-6 lg:p-8">
        {error && (
          <div className="mb-6 flex items-center justify-between rounded-lg border border-red-500/20 bg-red-500/[0.06] px-4 py-3">
            <p className="text-sm font-medium text-red-400">{error}</p>
            <button
              onClick={() => fetchKnowledgeBases()}
              className="rounded bg-red-600 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-red-700"
            >
              Retry
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {/* CREATE CARD - Dashed border, + icon, centered text */}
          <button
            type="button"
            onClick={() => setShowCreate(true)}
            className="group flex min-h-[280px] flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-white/[0.12] bg-transparent p-5 transition hover:border-cyan-400/40 hover:bg-cyan-500/[0.02]"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-white/[0.08] bg-white/[0.03] text-zinc-500 transition group-hover:text-cyan-400">
              <Plus size={22} />
            </div>
            <div className="text-center">
              <p className="text-sm font-semibold text-zinc-200 group-hover:text-cyan-400">
                Create Knowledge Base
              </p>
              <p className="mt-1 text-xs text-zinc-500">
                Add sources for agents
              </p>
            </div>
          </button>

          {/* LOADING SKELETONS */}
          {loading &&
            Array.from({ length: 3 }).map((_, index) => (
              <div
                key={`skeleton-${index}`}
                className="min-h-[280px] animate-pulse rounded-xl border border-white/[0.08] bg-[#101012] p-5"
              >
                <div className="h-10 w-10 rounded-lg bg-white/[0.08]" />
                <div className="mt-5 h-4 w-2/3 rounded bg-white/[0.08]" />
                <div className="mt-2 h-3 w-1/2 rounded bg-white/[0.08]" />
                <div className="mt-8 border-t border-white/[0.06]" />
                <div className="mt-6 flex justify-between">
                  <div className="h-3 w-1/4 rounded bg-white/[0.08]" />
                  <div className="h-3 w-1/4 rounded bg-white/[0.08]" />
                </div>
              </div>
            ))}

          {/* KNOWLEDGE BASE CARDS */}
          {!loading &&
            bases.map((base) => (
              <div
                key={base.id}
                onClick={() => handleOpenKnowledgeBase(base)}
                role="button"
                tabIndex={0}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    handleOpenKnowledgeBase(base);
                  }
                }}
                className="group relative flex min-h-[280px] cursor-pointer flex-col rounded-xl border border-white/[0.08] bg-[#101012] p-5 transition hover:border-cyan-400/30 hover:shadow-md"
              >
                {/* TOP ROW: icon + READY badge */}
                <div className="flex items-start justify-between">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-cyan-400/20 bg-cyan-400/[0.06]">
                    <Database size={18} className="text-cyan-400" />
                  </div>

                  <span className="flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/[0.08] px-2 py-0.5 text-[10px] font-bold tracking-wider text-emerald-400">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                    READY
                  </span>
                </div>

                {/* NAME */}
                <h3 className="mt-4 truncate text-base font-semibold text-zinc-100">
                  {base.name}
                </h3>

                {/* ID */}
                <p className="mt-1 truncate font-mono text-[11px] text-zinc-500">
                  {base.id}
                </p>

                {/* DIVIDER */}
                <div className="mt-4 border-t border-white/[0.06]" />

                {/* BOTTOM ROW */}
                <div className="mt-auto flex items-center justify-between pt-4">
                  <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                    <Folder size={13} />
                    <span>
                      {base.sourcesCount} source
                      {base.sourcesCount !== 1 ? "s" : ""}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-zinc-500">
                    <Clock size={12} />
                    <span>{formatRelativeTime(base.updated_at)}</span>
                  </div>
                </div>

                {/* HOVER CHEVRON */}
                <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-0 transition group-hover:opacity-100 text-zinc-600">
                  <ChevronRight size={20} />
                </div>
              </div>
            ))}

          {/* EMPTY STATE */}
          {!loading && !error && bases.length === 0 && (
            <div className="col-span-full flex min-h-[280px] flex-col items-center justify-center rounded-xl border border-white/[0.08] bg-[#101012] py-16 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/[0.05] text-zinc-500">
                <Database size={20} />
              </div>
              <p className="mt-4 text-sm font-semibold text-zinc-100">
                No Knowledge Bases
              </p>
              <p className="mt-1 max-w-sm text-xs text-zinc-500">
                Create your first knowledge base to provide information for your
                AI agents.
              </p>
            </div>
          )}
        </div>
      </main>

      {/* MODALS */}
      {showCreate && (
        <CreateKnowledgeBase
          onClose={() => setShowCreate(false)}
          onCreate={handleCreate}
        />
      )}

      {showCreateSource && createdKnowledgeBaseId && (
        <CreateSource
          knowledgeBaseId={createdKnowledgeBaseId}
          onClose={() => {
            setShowCreateSource(false);
            setCreatedKnowledgeBaseId(null);
          }}
          onCreate={() => {
            setShowCreateSource(false);
            const knowledgeBaseId = createdKnowledgeBaseId;
            setCreatedKnowledgeBaseId(null);
            showToast("Source created successfully");
            if (knowledgeBaseId) {
              navigate(`/knowledge-base/${knowledgeBaseId}/sources`);
            }
          }}
        />
      )}

      {showView && selectedKnowledgeBase && (
        <ViewKnowledgeBase
          knowledgeBaseId={selectedKnowledgeBase.id}
          onClose={() => {
            setShowView(false);
            setSelectedKnowledgeBase(null);
          }}
        />
      )}

      {showEdit && selectedKnowledgeBase && (
        <EditKnowledgeBase
          knowledgeBaseId={selectedKnowledgeBase.id}
          onClose={() => {
            setShowEdit(false);
            setSelectedKnowledgeBase(null);
          }}
          onUpdated={handleUpdated}
        />
      )}

      {showDelete && selectedKnowledgeBase && (
        <DeleteKnowledgeBase
          knowledgeBaseId={selectedKnowledgeBase.id}
          knowledgeBaseName={selectedKnowledgeBase.name}
          onClose={() => {
            setShowDelete(false);
            setSelectedKnowledgeBase(null);
          }}
          onDeleted={handleDeleted}
        />
      )}
    </div>
  );
}