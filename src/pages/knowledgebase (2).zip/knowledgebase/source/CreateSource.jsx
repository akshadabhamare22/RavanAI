import React, { useState } from "react";
import axios from "axios";
import { X, Loader2, Upload } from "lucide-react";
import config from "../../../config/Config";

const CreateSource = ({ knowledgeBaseId, onClose, onCreate }) => {
  const [title, setTitle] = useState("");
  const [sourceType, setSourceType] = useState("text");
  const [content, setContent] = useState("");
  const [url, setUrl] = useState("");

  // File state
  const [selectedFile, setSelectedFile] = useState(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];

    if (!file) {
      setSelectedFile(null);
      return;
    }

    setSelectedFile(file);

    // Automatically use file name as title if title is empty
    if (!title.trim()) {
      const fileNameWithoutExtension = file.name.replace(/\.[^/.]+$/, "");
      setTitle(fileNameWithoutExtension);
    }

    setError("");
  };

  const handleSourceTypeChange = (e) => {
    const type = e.target.value;

    setSourceType(type);
    setError("");

    // Reset type-specific fields
    if (type !== "text") {
      setContent("");
    }

    if (type !== "url") {
      setUrl("");
    }

    if (type !== "file") {
      setSelectedFile(null);
    }
  };

  const handleCreate = async () => {
    setError("");

    // Common validation
    if (!knowledgeBaseId) {
      setError("Knowledge base ID is missing.");
      return;
    }

    /*
     * ============================================================
     * FILE UPLOAD SOURCE
     * POST /knowledge-bases/{knowledge_base_id}/sources/upload
     * Content-Type: multipart/form-data
     * ============================================================
     */
    if (sourceType === "file") {
      if (!selectedFile) {
        setError("Please select a file.");
        return;
      }

      try {
        setLoading(true);

        const formData = new FormData();

        formData.append("file", selectedFile);

        const response = await axios.post(
          `${config.BASE_URL}/knowledge-bases/${knowledgeBaseId}/sources/upload`,
          formData,
          {
            headers: {
              Accept: "*/*",
            },
          }
        );

        console.log("File source uploaded successfully:", response.data);

        if (onCreate) {
          onCreate(response.data);
        }

        onClose();
      } catch (err) {
        console.error("Upload Source Error:", err);

        const errorMessage =
          err?.response?.data?.detail ||
          err?.response?.data?.message ||
          "Failed to upload source. Please try again.";

        setError(
          Array.isArray(errorMessage)
            ? errorMessage.map((item) => item?.msg || "").join(", ")
            : errorMessage
        );
      } finally {
        setLoading(false);
      }

      return;
    }

    /*
     * ============================================================
     * TEXT / URL SOURCE
     * POST /knowledge-bases/{knowledge_base_id}/sources
     * Content-Type: application/json
     * ============================================================
     */

    if (!title.trim()) {
      setError("Title is required.");
      return;
    }

    if (sourceType === "text" && !content.trim()) {
      setError("Content is required for text source.");
      return;
    }

    if (sourceType === "url" && !url.trim()) {
      setError("URL is required for URL source.");
      return;
    }

    try {
      setLoading(true);

      const payload = {
        title: title.trim(),
        source_type: sourceType,
        content: sourceType === "text" ? content.trim() : "",
        url: sourceType === "url" ? url.trim() : "",
        file_name: "",
        file_size: 0,
      };

      const response = await axios.post(
        `${config.BASE_URL}/knowledge-bases/${knowledgeBaseId}/sources`,
        payload,
        {
          headers: {
            "Content-Type": "application/json",
            Accept: "*/*",
          },
        }
      );

      console.log("Source created successfully:", response.data);

      if (onCreate) {
        onCreate(response.data);
      }

      onClose();
    } catch (err) {
      console.error("Create Source Error:", err);

      const errorMessage =
        err?.response?.data?.detail ||
        err?.response?.data?.message ||
        "Failed to create source. Please try again.";

      setError(
        Array.isArray(errorMessage)
          ? errorMessage.map((item) => item?.msg || "").join(", ")
          : errorMessage
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
      <div className="w-full max-w-2xl rounded-xl bg-white shadow-2xl">

        {/* Header */}
        <div className="flex items-center justify-between border-b border-gray-200 px-6 py-4">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">
              Create Source
            </h2>

            <p className="mt-1 text-sm text-gray-500">
              Add a new source to this knowledge base
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="rounded-lg p-2 text-gray-500 transition hover:bg-gray-100 hover:text-gray-700 disabled:cursor-not-allowed"
          >
            <X size={20} />
          </button>
        </div>

        {/* Body */}
        <div className="max-h-[70vh] overflow-y-auto px-6 py-5">

          {/* Error */}
          {error && (
            <div className="mb-5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600">
              {error}
            </div>
          )}

          {/* Source Type */}
          <div className="mb-5">
            <label className="mb-2 block text-sm font-medium text-gray-700">
              Source Type <span className="text-red-500">*</span>
            </label>

            <select
              value={sourceType}
              onChange={handleSourceTypeChange}
              disabled={loading}
              className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2.5 text-sm text-gray-900 outline-none transition focus:border-[#2759a2] focus:ring-1 focus:ring-[#2759a2] disabled:bg-gray-100"
            >
              <option value="text">Text</option>
              <option value="url">URL</option>
              <option value="file">File</option>
            </select>
          </div>

          {/* =====================================================
              TEXT SOURCE
          ====================================================== */}
          {sourceType === "text" && (
            <>
              {/* Title */}
              <div className="mb-5">
                <label className="mb-2 block text-sm font-medium text-gray-700">
                  Title <span className="text-red-500">*</span>
                </label>

                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter source title"
                  disabled={loading}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-900 outline-none transition focus:border-[#2759a2] focus:ring-1 focus:ring-[#2759a2] disabled:bg-gray-100"
                />
              </div>

              {/* Content */}
              <div className="mb-5">
                <label className="mb-2 block text-sm font-medium text-gray-700">
                  Content <span className="text-red-500">*</span>
                </label>

                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Enter source content"
                  rows={6}
                  disabled={loading}
                  className="w-full resize-none rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-900 outline-none transition focus:border-[#2759a2] focus:ring-1 focus:ring-[#2759a2] disabled:bg-gray-100"
                />
              </div>
            </>
          )}

          {/* =====================================================
              URL SOURCE
          ====================================================== */}
          {sourceType === "url" && (
            <>
              {/* Title */}
              <div className="mb-5">
                <label className="mb-2 block text-sm font-medium text-gray-700">
                  Title <span className="text-red-500">*</span>
                </label>

                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter source title"
                  disabled={loading}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-900 outline-none transition focus:border-[#2759a2] focus:ring-1 focus:ring-[#2759a2] disabled:bg-gray-100"
                />
              </div>

              {/* URL */}
              <div className="mb-5">
                <label className="mb-2 block text-sm font-medium text-gray-700">
                  URL <span className="text-red-500">*</span>
                </label>

                <input
                  type="url"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://example.com"
                  disabled={loading}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm text-gray-900 outline-none transition focus:border-[#2759a2] focus:ring-1 focus:ring-[#2759a2] disabled:bg-gray-100"
                />
              </div>
            </>
          )}

          {/* =====================================================
              FILE SOURCE
          ====================================================== */}
          {sourceType === "file" && (
            <div className="mb-5">

              <label className="mb-2 block text-sm font-medium text-gray-700">
                Upload File <span className="text-red-500">*</span>
              </label>

              <div className="rounded-lg border-2 border-dashed border-gray-300 p-6 text-center transition hover:border-[#2759a2]">

                <Upload
                  size={32}
                  className="mx-auto mb-3 text-gray-400"
                />

                <p className="mb-2 text-sm font-medium text-gray-700">
                  Select a file to upload
                </p>

                <p className="mb-4 text-xs text-gray-500">
                  PDF, DOC, DOCX, TXT and other supported files
                </p>

                <label className="inline-flex cursor-pointer items-center rounded-lg bg-[#2759a2] px-4 py-2.5 text-sm font-medium text-white transition hover:bg-[#1f4b8a]">
                  <Upload size={17} className="mr-2" />

                  Choose File

                  <input
                    type="file"
                    onChange={handleFileChange}
                    disabled={loading}
                    className="hidden"
                  />
                </label>

                {/* Selected File */}
                {selectedFile && (
                  <div className="mt-4 rounded-lg border border-gray-200 bg-gray-50 px-4 py-3 text-left">

                    <div className="flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium text-gray-800">
                          {selectedFile.name}
                        </p>

                        <p className="mt-1 text-xs text-gray-500">
                          {(selectedFile.size / 1024).toFixed(2)} KB
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => setSelectedFile(null)}
                        disabled={loading}
                        className="rounded-md p-1 text-gray-400 hover:bg-gray-200 hover:text-red-500"
                      >
                        <X size={17} />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 border-t border-gray-200 px-6 py-4">

          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="rounded-lg border border-gray-300 px-5 py-2.5 text-sm font-medium text-gray-700 transition hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-60"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleCreate}
            disabled={loading}
            className="flex items-center gap-2 rounded-lg bg-[#2759a2] px-5 py-2.5 text-sm font-medium text-white transition hover:bg-[#1f4b8a] disabled:cursor-not-allowed disabled:opacity-60"
          >
            {loading && (
              <Loader2
                size={17}
                className="animate-spin"
              />
            )}

            {loading ? "Creating..." : "Create Source"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreateSource;