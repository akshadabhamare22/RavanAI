import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

import {
  Plus,
  Eye,
  Trash2,
  RefreshCw,
  FileText,
  Link as LinkIcon,
  File,
  Loader2,
  AlertCircle,
  ArrowLeft,
} from "lucide-react";

import config from "../../../config/Config";

import CreateSource from "./CreateSource";
import ViewSource from "./ViewSource";
import DeleteSource from "./DeleteSource";

const Source = ({ knowledgeBaseId: propKnowledgeBaseId, knowledgeBaseName }) => {
  // ============================================================
  // ROUTE PARAMETER
  // ============================================================

  const { knowledgeBaseId: routeKnowledgeBaseId } = useParams();
  const navigate = useNavigate();

  // Route ID has priority
  const knowledgeBaseId =
    routeKnowledgeBaseId || propKnowledgeBaseId;

  // ============================================================
  // STATE
  // ============================================================

  const [sources, setSources] = useState([]);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [error, setError] = useState("");

  // ============================================================
  // MODALS
  // ============================================================

  const [showCreate, setShowCreate] = useState(false);
  const [showView, setShowView] = useState(false);
  const [showDelete, setShowDelete] = useState(false);

  // ============================================================
  // SELECTED SOURCE
  // ============================================================

  const [selectedSource, setSelectedSource] = useState(null);

  // ============================================================
  // TOAST
  // ============================================================

  const [toast, setToast] = useState({
    show: false,
    message: "",
    type: "success",
  });

  // ============================================================
  // DEBUG
  // ============================================================

  useEffect(() => {
    console.log("Knowledge Base ID:", knowledgeBaseId);
  }, [knowledgeBaseId]);

  // ============================================================
  // GET ALL SOURCES
  //
  // GET
  // /api/v1/knowledge-bases/{knowledge_base_id}/sources
  // ============================================================

  const fetchSources = async (showRefreshLoader = false) => {
    if (!knowledgeBaseId) {
      setError("Knowledge base ID is missing.");
      setSources([]);
      setLoading(false);
      return;
    }

    try {
      if (showRefreshLoader) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      setError("");

      const response = await axios.get(
        `${config.BASE_URL}/knowledge-bases/${knowledgeBaseId}/sources`,
        {
          headers: {
            Accept: "*/*",
          },
        }
      );

      console.log("Sources API Response:", response.data);

      setSources(response.data?.items || []);
    } catch (err) {
      console.error("Fetch Sources Error:", err);

      const errorMessage =
        err?.response?.data?.detail ||
        err?.response?.data?.message ||
        "Failed to load sources.";

      setError(
        Array.isArray(errorMessage)
          ? errorMessage
              .map((item) => item?.msg || "")
              .join(", ")
          : errorMessage
      );

      setSources([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // ============================================================
  // INITIAL LOAD
  // ============================================================

  useEffect(() => {
    fetchSources();
  }, [knowledgeBaseId]);

  // ============================================================
  // TOAST
  // ============================================================

  const showToast = (message, type = "success") => {
    setToast({
      show: true,
      message,
      type,
    });

    setTimeout(() => {
      setToast({
        show: false,
        message: "",
        type: "success",
      });
    }, 3000);
  };

  // ============================================================
  // CREATE SOURCE SUCCESS
  // ============================================================

  const handleSourceCreated = async (createdSource) => {
    console.log("Created Source:", createdSource);

    setShowCreate(false);

    await fetchSources(true);

    showToast("Source created successfully.");
  };

  // ============================================================
  // VIEW SOURCE
  // ============================================================

  const handleViewSource = (source) => {
    setSelectedSource(source);
    setShowView(true);
  };

  // ============================================================
  // DELETE SOURCE CLICK
  // ============================================================

  const handleDeleteClick = (source) => {
    setSelectedSource(source);
    setShowDelete(true);
  };

  // ============================================================
  // SOURCE DELETED
  // ============================================================

  const handleSourceDeleted = async (sourceId) => {
    console.log("Deleted Source ID:", sourceId);

    setShowDelete(false);
    setSelectedSource(null);

    await fetchSources(true);

    showToast("Source deleted successfully.");
  };

  // ============================================================
  // REFRESH
  // ============================================================

  const handleRefresh = () => {
    fetchSources(true);
  };

  // ============================================================
  // BACK TO KNOWLEDGE BASE
  // ============================================================

  const handleBack = () => {
    navigate("/knowledge-base");
  };

  // ============================================================
  // DATE FORMAT
  // ============================================================

  const formatDate = (date) => {
    if (!date) return "-";

    try {
      return new Date(date).toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      });
    } catch {
      return "-";
    }
  };

  // ============================================================
  // FILE SIZE
  // ============================================================

  const formatFileSize = (size) => {
    if (!size || Number(size) === 0) {
      return "-";
    }

    const bytes = Number(size);

    if (bytes < 1024) {
      return `${bytes} B`;
    }

    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(2)} KB`;
    }

    if (bytes < 1024 * 1024 * 1024) {
      return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    }

    return `${(
      bytes /
      (1024 * 1024 * 1024)
    ).toFixed(2)} GB`;
  };

  // ============================================================
  // SOURCE TYPE ICON
  // ============================================================

  const getSourceIcon = (sourceType) => {
    switch (sourceType) {
      case "text":
        return <FileText size={18} />;

      case "url":
        return <LinkIcon size={18} />;

      case "file":
        return <File size={18} />;

      default:
        return <FileText size={18} />;
    }
  };

  // ============================================================
  // SOURCE TYPE STYLE
  // ============================================================

  const getSourceTypeStyle = (sourceType) => {
    switch (sourceType) {
      case "text":
        return "bg-blue-50 text-blue-700";

      case "url":
        return "bg-purple-50 text-purple-700";

      case "file":
        return "bg-orange-50 text-orange-700";

      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  // ============================================================
  // LOADING
  // ============================================================

  if (loading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <Loader2
            size={22}
            className="animate-spin text-[#2759a2]"
          />
          Loading sources...
        </div>
      </div>
    );
  }

  // ============================================================
  // MAIN UI
  // ============================================================

  return (
    <div className="w-full">

      {/* ======================================================
          TOAST
      ======================================================= */}

      {toast.show && (
        <div
          className={`fixed right-5 top-5 z-[100] flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium text-white shadow-lg ${
            toast.type === "success"
              ? "bg-green-600"
              : "bg-red-600"
          }`}
        >
          {toast.message}
        </div>
      )}

      {/* ======================================================
          HEADER
      ======================================================= */}

      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">

        <div>
          {/* Back */}
          <button
            type="button"
            onClick={handleBack}
            className="mb-3 inline-flex items-center gap-2 text-sm font-medium text-gray-500 transition hover:text-[#2759a2]"
          >
            <ArrowLeft size={17} />
            All Knowledge Bases
          </button>

          <h2 className="text-xl font-semibold text-gray-900">
            Sources
          </h2>

          <p className="mt-1 text-sm text-gray-500">
            {knowledgeBaseName
              ? `Manage sources for ${knowledgeBaseName}`
              : "Manage knowledge base sources"}
          </p>
        </div>

        <div className="flex items-center gap-3">

          {/* Refresh */}

          <button
            type="button"
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 transition hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-60"
          >
            <RefreshCw
              size={17}
              className={
                refreshing
                  ? "animate-spin"
                  : ""
              }
            />

            Refresh
          </button>

          {/* Add Source */}

          <button
            type="button"
            onClick={() => {
              setSelectedSource(null);
              setShowCreate(true);
            }}
            className="flex items-center gap-2 rounded-lg bg-[#2759a2] px-4 py-2.5 text-sm font-medium text-white transition hover:bg-[#1f4b8a]"
          >
            <Plus size={18} />

            Add Source
          </button>
        </div>
      </div>

      {/* ======================================================
          ERROR
      ======================================================= */}

      {error && (
        <div className="mb-5 flex items-start gap-3 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600">

          <AlertCircle
            size={18}
            className="mt-0.5 shrink-0"
          />

          <div>
            <p className="font-medium">
              Failed to load sources
            </p>

            <p className="mt-1">
              {error}
            </p>
          </div>
        </div>
      )}

      {/* ======================================================
          SOURCE COUNT
      ======================================================= */}

      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-gray-500">
          {sources.length}{" "}
          {sources.length === 1
            ? "source"
            : "sources"}
        </p>
      </div>

      {/* ======================================================
          EMPTY STATE
      ======================================================= */}

      {!error && sources.length === 0 && (
        <div className="rounded-xl border border-dashed border-gray-300 bg-white px-6 py-16 text-center">

          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-gray-100">
            <FileText
              size={26}
              className="text-gray-400"
            />
          </div>

          <h3 className="text-base font-semibold text-gray-900">
            No sources found
          </h3>

          <p className="mx-auto mt-2 max-w-md text-sm text-gray-500">
            This knowledge base doesn't have any
            sources yet. Add a text, URL, or file
            source to get started.
          </p>

          <button
            type="button"
            onClick={() => setShowCreate(true)}
            className="mt-5 inline-flex items-center gap-2 rounded-lg bg-[#2759a2] px-4 py-2.5 text-sm font-medium text-white transition hover:bg-[#1f4b8a]"
          >
            <Plus size={17} />
            Add Source
          </button>
        </div>
      )}

      {/* ======================================================
          SOURCE TABLE
      ======================================================= */}

      {sources.length > 0 && (
        <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">

          <div className="max-h-[520px] overflow-y-auto overflow-x-auto">

            <table className="w-full min-w-[900px] border-collapse">

              {/* TABLE HEADER */}

              <thead className="sticky top-0 z-10 bg-gray-100">
                <tr className="border-b border-gray-200">

                  <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">
                    Title
                  </th>

                  <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">
                    Type
                  </th>

                  <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">
                    File Name
                  </th>

                  <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">
                    File Size
                  </th>

                  <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">
                    Status
                  </th>

                  <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">
                    Created
                  </th>

                  <th className="px-5 py-3 text-center text-xs font-semibold uppercase tracking-wide text-gray-600">
                    Actions
                  </th>

                </tr>
              </thead>

              {/* TABLE BODY */}

              <tbody>

                {sources.map((source) => (
                  <tr
                    key={source.id}
                    className="border-b border-gray-100 transition hover:bg-gray-50"
                  >

                    {/* TITLE */}

                    <td className="px-5 py-4">

                      <div className="flex items-center gap-3">

                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-600">
                          {getSourceIcon(
                            source.source_type
                          )}
                        </div>

                        <div className="min-w-0">

                          <p className="truncate text-sm font-medium text-gray-900">
                            {source.title || "-"}
                          </p>

                          {source.content && (
                            <p className="mt-1 max-w-[300px] truncate text-xs text-gray-500">
                              {source.content}
                            </p>
                          )}

                          {source.url && (
                            <p className="mt-1 max-w-[300px] truncate text-xs text-gray-500">
                              {source.url}
                            </p>
                          )}

                        </div>

                      </div>

                    </td>

                    {/* TYPE */}

                    <td className="px-5 py-4">

                      <span
                        className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium ${getSourceTypeStyle(
                          source.source_type
                        )}`}
                      >
                        {getSourceIcon(
                          source.source_type
                        )}

                        {source.source_type || "-"}
                      </span>

                    </td>

                    {/* FILE NAME */}

                    <td className="px-5 py-4 text-sm text-gray-600">
                      <span className="block max-w-[200px] truncate">
                        {source.file_name || "-"}
                      </span>
                    </td>

                    {/* FILE SIZE */}

                    <td className="px-5 py-4 text-sm text-gray-600">
                      {formatFileSize(
                        source.file_size
                      )}
                    </td>

                    {/* STATUS */}

                    <td className="px-5 py-4">

                      <span
                        className={`inline-flex rounded-full px-3 py-1 text-xs font-medium ${
                          source.status === "active"
                            ? "bg-green-100 text-green-700"
                            : "bg-gray-100 text-gray-700"
                        }`}
                      >
                        {source.status || "-"}
                      </span>

                    </td>

                    {/* CREATED */}

                    <td className="px-5 py-4 text-sm text-gray-600">
                      {formatDate(
                        source.created_at
                      )}
                    </td>

                    {/* ACTIONS */}

                    <td className="px-5 py-4">

                      <div className="flex items-center justify-center gap-2">

                        {/* VIEW */}

                        <button
                          type="button"
                          onClick={() =>
                            handleViewSource(source)
                          }
                          title="View Source"
                          className="rounded-lg border border-gray-200 p-2 text-gray-600 transition hover:border-[#2759a2] hover:bg-blue-50 hover:text-[#2759a2]"
                        >
                          <Eye size={17} />
                        </button>

                        {/* DELETE */}

                        <button
                          type="button"
                          onClick={() =>
                            handleDeleteClick(source)
                          }
                          title="Delete Source"
                          className="rounded-lg border border-gray-200 p-2 text-gray-600 transition hover:border-red-200 hover:bg-red-50 hover:text-red-600"
                        >
                          <Trash2 size={17} />
                        </button>

                      </div>

                    </td>

                  </tr>
                ))}

              </tbody>

            </table>
          </div>
        </div>
      )}

      {/* ======================================================
          CREATE SOURCE MODAL
      ======================================================= */}

      {showCreate && knowledgeBaseId && (
        <CreateSource
          knowledgeBaseId={knowledgeBaseId}
          onClose={() =>
            setShowCreate(false)
          }
          onCreate={handleSourceCreated}
        />
      )}

      {/* ======================================================
          VIEW SOURCE MODAL
      ======================================================= */}

      {showView && selectedSource && (
        <ViewSource
          knowledgeBaseId={knowledgeBaseId}
          sourceId={selectedSource.id}
          onClose={() => {
            setShowView(false);
            setSelectedSource(null);
          }}
        />
      )}

      {/* ======================================================
          DELETE SOURCE MODAL
      ======================================================= */}

      {showDelete && selectedSource && (
        <DeleteSource
          knowledgeBaseId={knowledgeBaseId}
          sourceId={selectedSource.id}
          sourceTitle={selectedSource.title}
          onClose={() => {
            setShowDelete(false);
            setSelectedSource(null);
          }}
          onDelete={handleSourceDeleted}
        />
      )}

    </div>
  );
};

export default Source;