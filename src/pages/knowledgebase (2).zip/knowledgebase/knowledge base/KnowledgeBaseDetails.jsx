import {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";

import {
  useNavigate,
  useParams,
  useSearchParams,
  useLocation,
} from "react-router-dom";

import { ArrowLeft, Plus, RefreshCw, Folder } from "lucide-react";

import axios from "axios";

// ============================================================
// SOURCE MODULE
// ============================================================

import Source from "../source/Source";
import CreateSource from "../source/CreateSource";
import DeleteSource from "../source/DeleteSource";
import ViewSource from "../source/ViewSource";
import { getSources, getApiErrorMessage } from "../source/sourceApi";

/*
 * ============================================================
 * ROUTE
 * ============================================================
 *
 *   /knowledge-base/:id
 *   /knowledge-base/:id?addSource=true   -> opens "Add Source" immediately
 *
 * The Knowledge Base ID ALWAYS comes from the URL, so the page
 * (and the Add Source modal) work correctly after a browser
 * refresh and never depend on stale parent state.
 *
 * API
 *   GET /api/v1/knowledge-bases/{id}
 *   GET /api/v1/knowledge-bases/{id}/sources
 */

export default function KnowledgeBaseDetails() {
  const { id: knowledgeBaseId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();

  // ============================================================
  // STATES
  // ============================================================

  // KB name can be shown instantly from the navigation state
  // that KnowledgeBase.jsx passes right after creation.
  const [knowledgeBase, setKnowledgeBase] = useState(
    location.state?.knowledgeBase?.id === knowledgeBaseId
      ? location.state.knowledgeBase
      : null
  );
  const [kbError, setKbError] = useState("");

  const [sources, setSources] = useState([]);
  const [sourcesLoading, setSourcesLoading] = useState(true);
  const [sourcesError, setSourcesError] = useState("");
  const [refreshing, setRefreshing] = useState(false);

  const [search, setSearch] = useState("");
  const [toast, setToast] = useState(null);

  // Modals
  // "Add Source" is open when the URL says so (?addSource=true, which is
  // what makes it open right after a KB is created and survive a refresh)
  // OR when the user clicked an "Add Source" button.
  const [manualCreateOpen, setManualCreateOpen] = useState(false);
  const showCreateSource =
    manualCreateOpen || searchParams.get("addSource") === "true";
  const [viewSource, setViewSource] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  // Ignore responses that belong to a previous KB / older request
  const sourcesRequestRef = useRef(0);

  // ============================================================
  // TOAST
  // ============================================================

  const toastTimerRef = useRef(null);

  const showToast = useCallback((message) => {
    setToast(message);

    clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setToast(null), 3000);
  }, []);

  useEffect(() => () => clearTimeout(toastTimerRef.current), []);

  // ============================================================
  // GET KNOWLEDGE BASE
  // ============================================================

  useEffect(() => {
    if (!knowledgeBaseId) return;

    let cancelled = false;

    const loadKnowledgeBase = async () => {
      try {
        setKbError("");

        const response = await axios.get(
          `${import.meta.env.VITE_API_BASE_URL}/api/v1/knowledge-bases/${knowledgeBaseId}`,
          { headers: { Accept: "*/*" } }
        );

        if (!cancelled) setKnowledgeBase(response.data);
      } catch (err) {
        console.error("Get Knowledge Base Error:", err);

        if (!cancelled) {
          setKbError(
            getApiErrorMessage(err, "Failed to load knowledge base.")
          );
        }
      }
    };

    loadKnowledgeBase();

    return () => {
      cancelled = true;
    };
  }, [knowledgeBaseId]);

  // ============================================================
  // GET SOURCES  (source of truth = API)
  // ============================================================

  const loadSources = useCallback(
    async (showLoader = true) => {
      if (!knowledgeBaseId) return;

      const requestId = ++sourcesRequestRef.current;

      try {
        if (showLoader) setSourcesLoading(true);
        else setRefreshing(true);

        setSourcesError("");

        const list = await getSources(knowledgeBaseId);

        if (requestId !== sourcesRequestRef.current) return;

        setSources(list);
      } catch (err) {
        console.error("Get Sources Error:", err);

        if (requestId !== sourcesRequestRef.current) return;

        setSourcesError(getApiErrorMessage(err, "Failed to load sources."));
      } finally {
        if (requestId === sourcesRequestRef.current) {
          setSourcesLoading(false);
          setRefreshing(false);
        }
      }
    },
    [knowledgeBaseId]
  );

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadSources(true);
  }, [loadSources]);

  // ============================================================
  // Just created? -> show the toast once, then clear navigation state
  // (so a browser refresh does not repeat it).
  // ============================================================

  useEffect(() => {
    if (location.state?.justCreated !== true) return;

    // eslint-disable-next-line react-hooks/set-state-in-effect
    showToast("Knowledge base created");

    setSearchParams(searchParams, { replace: true, state: null });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.state]);

  // ============================================================
  // Open / close Add Source
  // ============================================================

  const openCreateSource = () => setManualCreateOpen(true);

  const closeCreateSource = () => {
    setManualCreateOpen(false);

    // Remove the one-time trigger so it does not re-open.
    if (searchParams.get("addSource") === "true") {
      const next = new URLSearchParams(searchParams);
      next.delete("addSource");
      setSearchParams(next, { replace: true });
    }
  };

  // ============================================================
  // CALLBACKS
  // ============================================================

  // Called by CreateSource after the Source API succeeded.
  const handleSourcesAdded = async (count) => {
    await loadSources(false);

    showToast(
      count === 1
        ? "Source added — indexing started"
        : `${count} sources added — indexing started`
    );
  };

  const handleSourceDeleted = async () => {
    await loadSources(false);
    showToast("Source deleted");
  };

  const handleRefresh = async () => {
    await loadSources(false);
    showToast("Sources refreshed");
  };

  // ============================================================
  // UI
  // ============================================================

  const shortId =
    knowledgeBaseId && knowledgeBaseId.length > 12
      ? `${knowledgeBaseId.slice(0, 6)}...${knowledgeBaseId.slice(-4)}`
      : knowledgeBaseId;

  const status = String(knowledgeBase?.status || "").toLowerCase();

  return (
    <div className="min-h-screen bg-zinc-100 text-zinc-900 transition-colors duration-300 dark:bg-[#09090B] dark:text-zinc-100">
      {/* TOAST */}
      {toast && (
        <div className="fixed right-6 top-6 z-[100] flex min-w-[280px] items-center gap-3 overflow-hidden rounded-xl border border-emerald-500/30 bg-white shadow-xl dark:bg-[#101012]">
          <div className="flex flex-1 items-center gap-3 px-4 py-3">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-500">
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polyline points="20 6 9 17 4 12" />
              </svg>
            </div>

            <span className="text-sm font-medium text-zinc-800 dark:text-zinc-200">
              {toast}
            </span>
          </div>
        </div>
      )}

      <main className="mx-auto max-w-[1600px] space-y-5 p-4 sm:p-6 lg:p-7">
        {/* BACK */}
        <button
          type="button"
          onClick={() => navigate("/knowledge-base")}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-500 transition hover:text-zinc-800 dark:hover:text-zinc-200"
        >
          <ArrowLeft size={13} />
          All Knowledge Bases
        </button>

        {/* HEADER */}
        <section className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-[22px] font-semibold tracking-tight sm:text-2xl">
                {knowledgeBase?.name || "Knowledge Base"}
              </h1>

              {status && (
                <span className="rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-emerald-600 dark:text-emerald-400">
                  {status}
                </span>
              )}
            </div>

            <div className="mt-1.5 flex items-center gap-2 text-sm text-zinc-600 dark:text-zinc-500">
              <span className="font-mono text-xs">{shortId}</span>
              <span>•</span>
              <span>
                <span className="font-semibold text-zinc-900 dark:text-zinc-200">
                  {sources.length}
                </span>{" "}
                source{sources.length !== 1 ? "s" : ""}
              </span>
            </div>

            {knowledgeBase?.description && (
              <p className="mt-2 max-w-2xl text-[13px] text-zinc-600 dark:text-zinc-400">
                {knowledgeBase.description}
              </p>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRefresh}
              disabled={refreshing || sourcesLoading}
              className="flex items-center gap-2 rounded-lg border border-black/[0.08] bg-white px-3 py-2 text-xs font-medium text-zinc-600 transition hover:bg-black/[0.03] disabled:cursor-not-allowed disabled:opacity-60 dark:border-white/[0.08] dark:bg-[#101012] dark:text-zinc-400 dark:hover:bg-white/[0.04]"
            >
              <RefreshCw
                size={13}
                className={refreshing ? "animate-spin" : ""}
              />
              Refresh
            </button>

            <button
              type="button"
              onClick={openCreateSource}
              disabled={Boolean(kbError)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-cyan-500 px-4 py-2 text-xs font-semibold text-white transition hover:bg-cyan-400 disabled:cursor-not-allowed disabled:opacity-60 dark:bg-cyan-400 dark:text-slate-950"
            >
              <Plus size={13} />
              Add Source
            </button>
          </div>
        </section>

        {/* KB LOAD ERROR */}
        {kbError && (
          <div className="rounded-xl border border-red-500/20 bg-red-500/[0.06] px-4 py-3">
            <p className="text-sm font-medium text-red-600 dark:text-red-400">
              {kbError}
            </p>
          </div>
        )}

        {/* SOURCES LOAD ERROR */}
        {sourcesError && (
          <div className="flex items-center justify-between gap-4 rounded-xl border border-red-500/20 bg-red-500/[0.06] px-4 py-3">
            <p className="text-sm font-medium text-red-600 dark:text-red-400">
              {sourcesError}
            </p>

            <button
              type="button"
              onClick={() => loadSources(true)}
              className="rounded-lg border border-red-500/30 px-3 py-1.5 text-xs font-medium text-red-600 transition hover:bg-red-500/10 dark:text-red-400"
            >
              Retry
            </button>
          </div>
        )}

        {/* TAB */}
        <div className="inline-flex items-center gap-2 rounded-lg border border-black/[0.08] bg-white px-3 py-1.5 text-xs font-medium dark:border-white/[0.08] dark:bg-[#101012]">
          <Folder size={13} />
          Sources
          <span className="rounded bg-black/[0.06] px-1.5 py-0.5 text-[10px] dark:bg-white/[0.08]">
            {sources.length}
          </span>
        </div>

        {/* SOURCE TABLE */}
        <Source
          sources={sources}
          loading={sourcesLoading}
          search={search}
          onSearchChange={setSearch}
          onAdd={openCreateSource}
          onView={setViewSource}
          onDelete={setDeleteTarget}
        />
      </main>

      {/* ======================================================
          MODALS
          The KB id is passed explicitly from the URL param.
      ======================================================= */}

      {showCreateSource && !kbError && (
        <CreateSource
          knowledgeBaseId={knowledgeBaseId}
          onClose={closeCreateSource}
          onSourcesAdded={handleSourcesAdded}
        />
      )}

      {viewSource && (
        <ViewSource source={viewSource} onClose={() => setViewSource(null)} />
      )}

      {deleteTarget && (
        <DeleteSource
          knowledgeBaseId={knowledgeBaseId}
          source={deleteTarget}
          onClose={() => setDeleteTarget(null)}
          onDeleted={handleSourceDeleted}
        />
      )}
    </div>
  );
}
